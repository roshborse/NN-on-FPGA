#include "relu_array_array_ap_ufixed_64u_relu_config4_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_10_fu_1854_p2() {
    add_ln415_10_fu_1854_p2 = (!zext_ln415_10_fu_1850_p1.read().is_01() || !trunc_ln708_4_fu_1824_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_10_fu_1850_p1.read()) + sc_biguint<6>(trunc_ln708_4_fu_1824_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_11_fu_1946_p2() {
    add_ln415_11_fu_1946_p2 = (!zext_ln415_11_fu_1942_p1.read().is_01() || !trunc_ln708_10_fu_1916_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_11_fu_1942_p1.read()) + sc_biguint<6>(trunc_ln708_10_fu_1916_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_12_fu_2038_p2() {
    add_ln415_12_fu_2038_p2 = (!zext_ln415_12_fu_2034_p1.read().is_01() || !trunc_ln708_11_fu_2008_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_12_fu_2034_p1.read()) + sc_biguint<6>(trunc_ln708_11_fu_2008_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_13_fu_2130_p2() {
    add_ln415_13_fu_2130_p2 = (!zext_ln415_13_fu_2126_p1.read().is_01() || !trunc_ln708_12_fu_2100_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_13_fu_2126_p1.read()) + sc_biguint<6>(trunc_ln708_12_fu_2100_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_14_fu_2222_p2() {
    add_ln415_14_fu_2222_p2 = (!zext_ln415_14_fu_2218_p1.read().is_01() || !trunc_ln708_13_fu_2192_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_14_fu_2218_p1.read()) + sc_biguint<6>(trunc_ln708_13_fu_2192_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_15_fu_2314_p2() {
    add_ln415_15_fu_2314_p2 = (!zext_ln415_15_fu_2310_p1.read().is_01() || !trunc_ln708_14_fu_2284_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_15_fu_2310_p1.read()) + sc_biguint<6>(trunc_ln708_14_fu_2284_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_16_fu_2406_p2() {
    add_ln415_16_fu_2406_p2 = (!zext_ln415_16_fu_2402_p1.read().is_01() || !trunc_ln708_15_fu_2376_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_16_fu_2402_p1.read()) + sc_biguint<6>(trunc_ln708_15_fu_2376_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_17_fu_2498_p2() {
    add_ln415_17_fu_2498_p2 = (!zext_ln415_17_fu_2494_p1.read().is_01() || !trunc_ln708_16_fu_2468_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_17_fu_2494_p1.read()) + sc_biguint<6>(trunc_ln708_16_fu_2468_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_18_fu_2590_p2() {
    add_ln415_18_fu_2590_p2 = (!zext_ln415_18_fu_2586_p1.read().is_01() || !trunc_ln708_17_fu_2560_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_18_fu_2586_p1.read()) + sc_biguint<6>(trunc_ln708_17_fu_2560_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_19_fu_2682_p2() {
    add_ln415_19_fu_2682_p2 = (!zext_ln415_19_fu_2678_p1.read().is_01() || !trunc_ln708_18_fu_2652_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_19_fu_2678_p1.read()) + sc_biguint<6>(trunc_ln708_18_fu_2652_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_1_fu_1026_p2() {
    add_ln415_1_fu_1026_p2 = (!zext_ln415_1_fu_1022_p1.read().is_01() || !trunc_ln708_5_fu_996_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_1_fu_1022_p1.read()) + sc_biguint<6>(trunc_ln708_5_fu_996_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_20_fu_2774_p2() {
    add_ln415_20_fu_2774_p2 = (!zext_ln415_20_fu_2770_p1.read().is_01() || !trunc_ln708_19_fu_2744_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_20_fu_2770_p1.read()) + sc_biguint<6>(trunc_ln708_19_fu_2744_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_21_fu_2866_p2() {
    add_ln415_21_fu_2866_p2 = (!zext_ln415_21_fu_2862_p1.read().is_01() || !trunc_ln708_20_fu_2836_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_21_fu_2862_p1.read()) + sc_biguint<6>(trunc_ln708_20_fu_2836_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_22_fu_2958_p2() {
    add_ln415_22_fu_2958_p2 = (!zext_ln415_22_fu_2954_p1.read().is_01() || !trunc_ln708_21_fu_2928_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_22_fu_2954_p1.read()) + sc_biguint<6>(trunc_ln708_21_fu_2928_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_23_fu_3050_p2() {
    add_ln415_23_fu_3050_p2 = (!zext_ln415_23_fu_3046_p1.read().is_01() || !trunc_ln708_22_fu_3020_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_23_fu_3046_p1.read()) + sc_biguint<6>(trunc_ln708_22_fu_3020_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_24_fu_3142_p2() {
    add_ln415_24_fu_3142_p2 = (!zext_ln415_24_fu_3138_p1.read().is_01() || !trunc_ln708_23_fu_3112_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_24_fu_3138_p1.read()) + sc_biguint<6>(trunc_ln708_23_fu_3112_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_25_fu_3234_p2() {
    add_ln415_25_fu_3234_p2 = (!zext_ln415_25_fu_3230_p1.read().is_01() || !trunc_ln708_24_fu_3204_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_25_fu_3230_p1.read()) + sc_biguint<6>(trunc_ln708_24_fu_3204_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_26_fu_3326_p2() {
    add_ln415_26_fu_3326_p2 = (!zext_ln415_26_fu_3322_p1.read().is_01() || !trunc_ln708_25_fu_3296_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_26_fu_3322_p1.read()) + sc_biguint<6>(trunc_ln708_25_fu_3296_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_27_fu_3418_p2() {
    add_ln415_27_fu_3418_p2 = (!zext_ln415_27_fu_3414_p1.read().is_01() || !trunc_ln708_26_fu_3388_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_27_fu_3414_p1.read()) + sc_biguint<6>(trunc_ln708_26_fu_3388_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_28_fu_3510_p2() {
    add_ln415_28_fu_3510_p2 = (!zext_ln415_28_fu_3506_p1.read().is_01() || !trunc_ln708_27_fu_3480_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_28_fu_3506_p1.read()) + sc_biguint<6>(trunc_ln708_27_fu_3480_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_29_fu_3602_p2() {
    add_ln415_29_fu_3602_p2 = (!zext_ln415_29_fu_3598_p1.read().is_01() || !trunc_ln708_28_fu_3572_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_29_fu_3598_p1.read()) + sc_biguint<6>(trunc_ln708_28_fu_3572_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_2_fu_1118_p2() {
    add_ln415_2_fu_1118_p2 = (!zext_ln415_2_fu_1114_p1.read().is_01() || !trunc_ln708_6_fu_1088_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_2_fu_1114_p1.read()) + sc_biguint<6>(trunc_ln708_6_fu_1088_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_30_fu_3694_p2() {
    add_ln415_30_fu_3694_p2 = (!zext_ln415_30_fu_3690_p1.read().is_01() || !trunc_ln708_29_fu_3664_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_30_fu_3690_p1.read()) + sc_biguint<6>(trunc_ln708_29_fu_3664_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_31_fu_3786_p2() {
    add_ln415_31_fu_3786_p2 = (!zext_ln415_31_fu_3782_p1.read().is_01() || !trunc_ln708_30_fu_3756_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_31_fu_3782_p1.read()) + sc_biguint<6>(trunc_ln708_30_fu_3756_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_32_fu_3878_p2() {
    add_ln415_32_fu_3878_p2 = (!zext_ln415_32_fu_3874_p1.read().is_01() || !trunc_ln708_31_fu_3848_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_32_fu_3874_p1.read()) + sc_biguint<6>(trunc_ln708_31_fu_3848_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_33_fu_3970_p2() {
    add_ln415_33_fu_3970_p2 = (!zext_ln415_33_fu_3966_p1.read().is_01() || !trunc_ln708_32_fu_3940_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_33_fu_3966_p1.read()) + sc_biguint<6>(trunc_ln708_32_fu_3940_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_34_fu_4062_p2() {
    add_ln415_34_fu_4062_p2 = (!zext_ln415_34_fu_4058_p1.read().is_01() || !trunc_ln708_33_fu_4032_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_34_fu_4058_p1.read()) + sc_biguint<6>(trunc_ln708_33_fu_4032_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_35_fu_4154_p2() {
    add_ln415_35_fu_4154_p2 = (!zext_ln415_35_fu_4150_p1.read().is_01() || !trunc_ln708_34_fu_4124_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_35_fu_4150_p1.read()) + sc_biguint<6>(trunc_ln708_34_fu_4124_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_36_fu_4246_p2() {
    add_ln415_36_fu_4246_p2 = (!zext_ln415_36_fu_4242_p1.read().is_01() || !trunc_ln708_35_fu_4216_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_36_fu_4242_p1.read()) + sc_biguint<6>(trunc_ln708_35_fu_4216_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_37_fu_4338_p2() {
    add_ln415_37_fu_4338_p2 = (!zext_ln415_37_fu_4334_p1.read().is_01() || !trunc_ln708_36_fu_4308_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_37_fu_4334_p1.read()) + sc_biguint<6>(trunc_ln708_36_fu_4308_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_38_fu_4430_p2() {
    add_ln415_38_fu_4430_p2 = (!zext_ln415_38_fu_4426_p1.read().is_01() || !trunc_ln708_37_fu_4400_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_38_fu_4426_p1.read()) + sc_biguint<6>(trunc_ln708_37_fu_4400_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_39_fu_4522_p2() {
    add_ln415_39_fu_4522_p2 = (!zext_ln415_39_fu_4518_p1.read().is_01() || !trunc_ln708_38_fu_4492_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_39_fu_4518_p1.read()) + sc_biguint<6>(trunc_ln708_38_fu_4492_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_3_fu_1210_p2() {
    add_ln415_3_fu_1210_p2 = (!zext_ln415_3_fu_1206_p1.read().is_01() || !trunc_ln708_7_fu_1180_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_3_fu_1206_p1.read()) + sc_biguint<6>(trunc_ln708_7_fu_1180_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_40_fu_4614_p2() {
    add_ln415_40_fu_4614_p2 = (!zext_ln415_40_fu_4610_p1.read().is_01() || !trunc_ln708_39_fu_4584_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_40_fu_4610_p1.read()) + sc_biguint<6>(trunc_ln708_39_fu_4584_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_41_fu_4706_p2() {
    add_ln415_41_fu_4706_p2 = (!zext_ln415_41_fu_4702_p1.read().is_01() || !trunc_ln708_40_fu_4676_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_41_fu_4702_p1.read()) + sc_biguint<6>(trunc_ln708_40_fu_4676_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_42_fu_4798_p2() {
    add_ln415_42_fu_4798_p2 = (!zext_ln415_42_fu_4794_p1.read().is_01() || !trunc_ln708_41_fu_4768_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_42_fu_4794_p1.read()) + sc_biguint<6>(trunc_ln708_41_fu_4768_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_43_fu_4890_p2() {
    add_ln415_43_fu_4890_p2 = (!zext_ln415_43_fu_4886_p1.read().is_01() || !trunc_ln708_42_fu_4860_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_43_fu_4886_p1.read()) + sc_biguint<6>(trunc_ln708_42_fu_4860_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_44_fu_4982_p2() {
    add_ln415_44_fu_4982_p2 = (!zext_ln415_44_fu_4978_p1.read().is_01() || !trunc_ln708_43_fu_4952_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_44_fu_4978_p1.read()) + sc_biguint<6>(trunc_ln708_43_fu_4952_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_45_fu_5074_p2() {
    add_ln415_45_fu_5074_p2 = (!zext_ln415_45_fu_5070_p1.read().is_01() || !trunc_ln708_44_fu_5044_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_45_fu_5070_p1.read()) + sc_biguint<6>(trunc_ln708_44_fu_5044_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_46_fu_5166_p2() {
    add_ln415_46_fu_5166_p2 = (!zext_ln415_46_fu_5162_p1.read().is_01() || !trunc_ln708_45_fu_5136_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_46_fu_5162_p1.read()) + sc_biguint<6>(trunc_ln708_45_fu_5136_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_47_fu_5258_p2() {
    add_ln415_47_fu_5258_p2 = (!zext_ln415_47_fu_5254_p1.read().is_01() || !trunc_ln708_46_fu_5228_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_47_fu_5254_p1.read()) + sc_biguint<6>(trunc_ln708_46_fu_5228_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_48_fu_5350_p2() {
    add_ln415_48_fu_5350_p2 = (!zext_ln415_48_fu_5346_p1.read().is_01() || !trunc_ln708_47_fu_5320_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_48_fu_5346_p1.read()) + sc_biguint<6>(trunc_ln708_47_fu_5320_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_49_fu_5442_p2() {
    add_ln415_49_fu_5442_p2 = (!zext_ln415_49_fu_5438_p1.read().is_01() || !trunc_ln708_48_fu_5412_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_49_fu_5438_p1.read()) + sc_biguint<6>(trunc_ln708_48_fu_5412_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_4_fu_1302_p2() {
    add_ln415_4_fu_1302_p2 = (!zext_ln415_4_fu_1298_p1.read().is_01() || !trunc_ln708_8_fu_1272_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_4_fu_1298_p1.read()) + sc_biguint<6>(trunc_ln708_8_fu_1272_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_50_fu_5534_p2() {
    add_ln415_50_fu_5534_p2 = (!zext_ln415_50_fu_5530_p1.read().is_01() || !trunc_ln708_49_fu_5504_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_50_fu_5530_p1.read()) + sc_biguint<6>(trunc_ln708_49_fu_5504_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_51_fu_5626_p2() {
    add_ln415_51_fu_5626_p2 = (!zext_ln415_51_fu_5622_p1.read().is_01() || !trunc_ln708_50_fu_5596_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_51_fu_5622_p1.read()) + sc_biguint<6>(trunc_ln708_50_fu_5596_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_52_fu_5718_p2() {
    add_ln415_52_fu_5718_p2 = (!zext_ln415_52_fu_5714_p1.read().is_01() || !trunc_ln708_51_fu_5688_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_52_fu_5714_p1.read()) + sc_biguint<6>(trunc_ln708_51_fu_5688_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_53_fu_5810_p2() {
    add_ln415_53_fu_5810_p2 = (!zext_ln415_53_fu_5806_p1.read().is_01() || !trunc_ln708_52_fu_5780_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_53_fu_5806_p1.read()) + sc_biguint<6>(trunc_ln708_52_fu_5780_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_54_fu_5902_p2() {
    add_ln415_54_fu_5902_p2 = (!zext_ln415_54_fu_5898_p1.read().is_01() || !trunc_ln708_53_fu_5872_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_54_fu_5898_p1.read()) + sc_biguint<6>(trunc_ln708_53_fu_5872_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_55_fu_5994_p2() {
    add_ln415_55_fu_5994_p2 = (!zext_ln415_55_fu_5990_p1.read().is_01() || !trunc_ln708_54_fu_5964_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_55_fu_5990_p1.read()) + sc_biguint<6>(trunc_ln708_54_fu_5964_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_56_fu_6086_p2() {
    add_ln415_56_fu_6086_p2 = (!zext_ln415_56_fu_6082_p1.read().is_01() || !trunc_ln708_55_fu_6056_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_56_fu_6082_p1.read()) + sc_biguint<6>(trunc_ln708_55_fu_6056_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_57_fu_6178_p2() {
    add_ln415_57_fu_6178_p2 = (!zext_ln415_57_fu_6174_p1.read().is_01() || !trunc_ln708_56_fu_6148_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_57_fu_6174_p1.read()) + sc_biguint<6>(trunc_ln708_56_fu_6148_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_58_fu_6270_p2() {
    add_ln415_58_fu_6270_p2 = (!zext_ln415_58_fu_6266_p1.read().is_01() || !trunc_ln708_57_fu_6240_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_58_fu_6266_p1.read()) + sc_biguint<6>(trunc_ln708_57_fu_6240_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_59_fu_6362_p2() {
    add_ln415_59_fu_6362_p2 = (!zext_ln415_59_fu_6358_p1.read().is_01() || !trunc_ln708_58_fu_6332_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_59_fu_6358_p1.read()) + sc_biguint<6>(trunc_ln708_58_fu_6332_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_5_fu_1394_p2() {
    add_ln415_5_fu_1394_p2 = (!zext_ln415_5_fu_1390_p1.read().is_01() || !trunc_ln708_9_fu_1364_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_5_fu_1390_p1.read()) + sc_biguint<6>(trunc_ln708_9_fu_1364_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_60_fu_6454_p2() {
    add_ln415_60_fu_6454_p2 = (!zext_ln415_60_fu_6450_p1.read().is_01() || !trunc_ln708_59_fu_6424_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_60_fu_6450_p1.read()) + sc_biguint<6>(trunc_ln708_59_fu_6424_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_61_fu_6546_p2() {
    add_ln415_61_fu_6546_p2 = (!zext_ln415_61_fu_6542_p1.read().is_01() || !trunc_ln708_60_fu_6516_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_61_fu_6542_p1.read()) + sc_biguint<6>(trunc_ln708_60_fu_6516_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_62_fu_6638_p2() {
    add_ln415_62_fu_6638_p2 = (!zext_ln415_62_fu_6634_p1.read().is_01() || !trunc_ln708_61_fu_6608_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_62_fu_6634_p1.read()) + sc_biguint<6>(trunc_ln708_61_fu_6608_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_63_fu_6730_p2() {
    add_ln415_63_fu_6730_p2 = (!zext_ln415_63_fu_6726_p1.read().is_01() || !trunc_ln708_62_fu_6700_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_63_fu_6726_p1.read()) + sc_biguint<6>(trunc_ln708_62_fu_6700_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_6_fu_1486_p2() {
    add_ln415_6_fu_1486_p2 = (!zext_ln415_6_fu_1482_p1.read().is_01() || !trunc_ln708_s_fu_1456_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_6_fu_1482_p1.read()) + sc_biguint<6>(trunc_ln708_s_fu_1456_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_7_fu_1578_p2() {
    add_ln415_7_fu_1578_p2 = (!zext_ln415_7_fu_1574_p1.read().is_01() || !trunc_ln708_1_fu_1548_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_7_fu_1574_p1.read()) + sc_biguint<6>(trunc_ln708_1_fu_1548_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_8_fu_1670_p2() {
    add_ln415_8_fu_1670_p2 = (!zext_ln415_8_fu_1666_p1.read().is_01() || !trunc_ln708_2_fu_1640_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_8_fu_1666_p1.read()) + sc_biguint<6>(trunc_ln708_2_fu_1640_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_9_fu_1762_p2() {
    add_ln415_9_fu_1762_p2 = (!zext_ln415_9_fu_1758_p1.read().is_01() || !trunc_ln708_3_fu_1732_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_9_fu_1758_p1.read()) + sc_biguint<6>(trunc_ln708_3_fu_1732_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_add_ln415_fu_934_p2() {
    add_ln415_fu_934_p2 = (!zext_ln415_fu_930_p1.read().is_01() || !trunc_ln_fu_904_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln415_fu_930_p1.read()) + sc_biguint<6>(trunc_ln_fu_904_p4.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_10_fu_1874_p2() {
    and_ln416_10_fu_1874_p2 = (tmp_43_fu_1834_p3.read() & xor_ln416_10_fu_1868_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_11_fu_1966_p2() {
    and_ln416_11_fu_1966_p2 = (tmp_46_fu_1926_p3.read() & xor_ln416_11_fu_1960_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_12_fu_2058_p2() {
    and_ln416_12_fu_2058_p2 = (tmp_49_fu_2018_p3.read() & xor_ln416_12_fu_2052_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_13_fu_2150_p2() {
    and_ln416_13_fu_2150_p2 = (tmp_52_fu_2110_p3.read() & xor_ln416_13_fu_2144_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_14_fu_2242_p2() {
    and_ln416_14_fu_2242_p2 = (tmp_55_fu_2202_p3.read() & xor_ln416_14_fu_2236_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_15_fu_2334_p2() {
    and_ln416_15_fu_2334_p2 = (tmp_58_fu_2294_p3.read() & xor_ln416_15_fu_2328_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_16_fu_2426_p2() {
    and_ln416_16_fu_2426_p2 = (tmp_61_fu_2386_p3.read() & xor_ln416_16_fu_2420_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_17_fu_2518_p2() {
    and_ln416_17_fu_2518_p2 = (tmp_64_fu_2478_p3.read() & xor_ln416_17_fu_2512_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_18_fu_2610_p2() {
    and_ln416_18_fu_2610_p2 = (tmp_67_fu_2570_p3.read() & xor_ln416_18_fu_2604_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_19_fu_2702_p2() {
    and_ln416_19_fu_2702_p2 = (tmp_70_fu_2662_p3.read() & xor_ln416_19_fu_2696_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_1_fu_1046_p2() {
    and_ln416_1_fu_1046_p2 = (tmp_16_fu_1006_p3.read() & xor_ln416_1_fu_1040_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_20_fu_2794_p2() {
    and_ln416_20_fu_2794_p2 = (tmp_73_fu_2754_p3.read() & xor_ln416_20_fu_2788_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_21_fu_2886_p2() {
    and_ln416_21_fu_2886_p2 = (tmp_76_fu_2846_p3.read() & xor_ln416_21_fu_2880_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_22_fu_2978_p2() {
    and_ln416_22_fu_2978_p2 = (tmp_79_fu_2938_p3.read() & xor_ln416_22_fu_2972_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_23_fu_3070_p2() {
    and_ln416_23_fu_3070_p2 = (tmp_82_fu_3030_p3.read() & xor_ln416_23_fu_3064_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_24_fu_3162_p2() {
    and_ln416_24_fu_3162_p2 = (tmp_85_fu_3122_p3.read() & xor_ln416_24_fu_3156_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_25_fu_3254_p2() {
    and_ln416_25_fu_3254_p2 = (tmp_88_fu_3214_p3.read() & xor_ln416_25_fu_3248_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_26_fu_3346_p2() {
    and_ln416_26_fu_3346_p2 = (tmp_91_fu_3306_p3.read() & xor_ln416_26_fu_3340_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_27_fu_3438_p2() {
    and_ln416_27_fu_3438_p2 = (tmp_94_fu_3398_p3.read() & xor_ln416_27_fu_3432_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_28_fu_3530_p2() {
    and_ln416_28_fu_3530_p2 = (tmp_97_fu_3490_p3.read() & xor_ln416_28_fu_3524_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_29_fu_3622_p2() {
    and_ln416_29_fu_3622_p2 = (tmp_100_fu_3582_p3.read() & xor_ln416_29_fu_3616_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_2_fu_1138_p2() {
    and_ln416_2_fu_1138_p2 = (tmp_19_fu_1098_p3.read() & xor_ln416_2_fu_1132_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_30_fu_3714_p2() {
    and_ln416_30_fu_3714_p2 = (tmp_103_fu_3674_p3.read() & xor_ln416_30_fu_3708_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_31_fu_3806_p2() {
    and_ln416_31_fu_3806_p2 = (tmp_106_fu_3766_p3.read() & xor_ln416_31_fu_3800_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_32_fu_3898_p2() {
    and_ln416_32_fu_3898_p2 = (tmp_109_fu_3858_p3.read() & xor_ln416_32_fu_3892_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_33_fu_3990_p2() {
    and_ln416_33_fu_3990_p2 = (tmp_112_fu_3950_p3.read() & xor_ln416_33_fu_3984_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_34_fu_4082_p2() {
    and_ln416_34_fu_4082_p2 = (tmp_115_fu_4042_p3.read() & xor_ln416_34_fu_4076_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_35_fu_4174_p2() {
    and_ln416_35_fu_4174_p2 = (tmp_118_fu_4134_p3.read() & xor_ln416_35_fu_4168_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_36_fu_4266_p2() {
    and_ln416_36_fu_4266_p2 = (tmp_121_fu_4226_p3.read() & xor_ln416_36_fu_4260_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_37_fu_4358_p2() {
    and_ln416_37_fu_4358_p2 = (tmp_124_fu_4318_p3.read() & xor_ln416_37_fu_4352_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_38_fu_4450_p2() {
    and_ln416_38_fu_4450_p2 = (tmp_127_fu_4410_p3.read() & xor_ln416_38_fu_4444_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_39_fu_4542_p2() {
    and_ln416_39_fu_4542_p2 = (tmp_130_fu_4502_p3.read() & xor_ln416_39_fu_4536_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_3_fu_1230_p2() {
    and_ln416_3_fu_1230_p2 = (tmp_22_fu_1190_p3.read() & xor_ln416_3_fu_1224_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_40_fu_4634_p2() {
    and_ln416_40_fu_4634_p2 = (tmp_133_fu_4594_p3.read() & xor_ln416_40_fu_4628_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_41_fu_4726_p2() {
    and_ln416_41_fu_4726_p2 = (tmp_136_fu_4686_p3.read() & xor_ln416_41_fu_4720_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_42_fu_4818_p2() {
    and_ln416_42_fu_4818_p2 = (tmp_139_fu_4778_p3.read() & xor_ln416_42_fu_4812_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_43_fu_4910_p2() {
    and_ln416_43_fu_4910_p2 = (tmp_142_fu_4870_p3.read() & xor_ln416_43_fu_4904_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_44_fu_5002_p2() {
    and_ln416_44_fu_5002_p2 = (tmp_145_fu_4962_p3.read() & xor_ln416_44_fu_4996_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_45_fu_5094_p2() {
    and_ln416_45_fu_5094_p2 = (tmp_148_fu_5054_p3.read() & xor_ln416_45_fu_5088_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_46_fu_5186_p2() {
    and_ln416_46_fu_5186_p2 = (tmp_151_fu_5146_p3.read() & xor_ln416_46_fu_5180_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_47_fu_5278_p2() {
    and_ln416_47_fu_5278_p2 = (tmp_154_fu_5238_p3.read() & xor_ln416_47_fu_5272_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_48_fu_5370_p2() {
    and_ln416_48_fu_5370_p2 = (tmp_157_fu_5330_p3.read() & xor_ln416_48_fu_5364_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_49_fu_5462_p2() {
    and_ln416_49_fu_5462_p2 = (tmp_160_fu_5422_p3.read() & xor_ln416_49_fu_5456_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_4_fu_1322_p2() {
    and_ln416_4_fu_1322_p2 = (tmp_25_fu_1282_p3.read() & xor_ln416_4_fu_1316_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_50_fu_5554_p2() {
    and_ln416_50_fu_5554_p2 = (tmp_163_fu_5514_p3.read() & xor_ln416_50_fu_5548_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_51_fu_5646_p2() {
    and_ln416_51_fu_5646_p2 = (tmp_166_fu_5606_p3.read() & xor_ln416_51_fu_5640_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_52_fu_5738_p2() {
    and_ln416_52_fu_5738_p2 = (tmp_169_fu_5698_p3.read() & xor_ln416_52_fu_5732_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_53_fu_5830_p2() {
    and_ln416_53_fu_5830_p2 = (tmp_172_fu_5790_p3.read() & xor_ln416_53_fu_5824_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_54_fu_5922_p2() {
    and_ln416_54_fu_5922_p2 = (tmp_175_fu_5882_p3.read() & xor_ln416_54_fu_5916_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_55_fu_6014_p2() {
    and_ln416_55_fu_6014_p2 = (tmp_178_fu_5974_p3.read() & xor_ln416_55_fu_6008_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_56_fu_6106_p2() {
    and_ln416_56_fu_6106_p2 = (tmp_181_fu_6066_p3.read() & xor_ln416_56_fu_6100_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_57_fu_6198_p2() {
    and_ln416_57_fu_6198_p2 = (tmp_184_fu_6158_p3.read() & xor_ln416_57_fu_6192_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_58_fu_6290_p2() {
    and_ln416_58_fu_6290_p2 = (tmp_187_fu_6250_p3.read() & xor_ln416_58_fu_6284_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_59_fu_6382_p2() {
    and_ln416_59_fu_6382_p2 = (tmp_190_fu_6342_p3.read() & xor_ln416_59_fu_6376_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_5_fu_1414_p2() {
    and_ln416_5_fu_1414_p2 = (tmp_28_fu_1374_p3.read() & xor_ln416_5_fu_1408_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_60_fu_6474_p2() {
    and_ln416_60_fu_6474_p2 = (tmp_193_fu_6434_p3.read() & xor_ln416_60_fu_6468_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_61_fu_6566_p2() {
    and_ln416_61_fu_6566_p2 = (tmp_196_fu_6526_p3.read() & xor_ln416_61_fu_6560_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_62_fu_6658_p2() {
    and_ln416_62_fu_6658_p2 = (tmp_199_fu_6618_p3.read() & xor_ln416_62_fu_6652_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_63_fu_6750_p2() {
    and_ln416_63_fu_6750_p2 = (tmp_202_fu_6710_p3.read() & xor_ln416_63_fu_6744_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_6_fu_1506_p2() {
    and_ln416_6_fu_1506_p2 = (tmp_31_fu_1466_p3.read() & xor_ln416_6_fu_1500_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_7_fu_1598_p2() {
    and_ln416_7_fu_1598_p2 = (tmp_34_fu_1558_p3.read() & xor_ln416_7_fu_1592_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_8_fu_1690_p2() {
    and_ln416_8_fu_1690_p2 = (tmp_37_fu_1650_p3.read() & xor_ln416_8_fu_1684_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_9_fu_1782_p2() {
    and_ln416_9_fu_1782_p2 = (tmp_40_fu_1742_p3.read() & xor_ln416_9_fu_1776_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_and_ln416_fu_954_p2() {
    and_ln416_fu_954_p2 = (tmp_13_fu_914_p3.read() & xor_ln416_fu_948_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_ap_block_state1() {
    ap_block_state1 = (esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read()));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_ap_done() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_done_reg.read();
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_ap_ready() {
    ap_ready = internal_ap_ready.read();
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_0_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_0_V_blk_n = data_V_data_0_V_empty_n.read();
    } else {
        data_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_0_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_0_V_read = ap_const_logic_1;
    } else {
        data_V_data_0_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_10_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_10_V_blk_n = data_V_data_10_V_empty_n.read();
    } else {
        data_V_data_10_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_10_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_10_V_read = ap_const_logic_1;
    } else {
        data_V_data_10_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_11_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_11_V_blk_n = data_V_data_11_V_empty_n.read();
    } else {
        data_V_data_11_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_11_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_11_V_read = ap_const_logic_1;
    } else {
        data_V_data_11_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_12_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_12_V_blk_n = data_V_data_12_V_empty_n.read();
    } else {
        data_V_data_12_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_12_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_12_V_read = ap_const_logic_1;
    } else {
        data_V_data_12_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_13_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_13_V_blk_n = data_V_data_13_V_empty_n.read();
    } else {
        data_V_data_13_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_13_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_13_V_read = ap_const_logic_1;
    } else {
        data_V_data_13_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_14_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_14_V_blk_n = data_V_data_14_V_empty_n.read();
    } else {
        data_V_data_14_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_14_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_14_V_read = ap_const_logic_1;
    } else {
        data_V_data_14_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_15_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_15_V_blk_n = data_V_data_15_V_empty_n.read();
    } else {
        data_V_data_15_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_15_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_15_V_read = ap_const_logic_1;
    } else {
        data_V_data_15_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_16_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_16_V_blk_n = data_V_data_16_V_empty_n.read();
    } else {
        data_V_data_16_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_16_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_16_V_read = ap_const_logic_1;
    } else {
        data_V_data_16_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_17_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_17_V_blk_n = data_V_data_17_V_empty_n.read();
    } else {
        data_V_data_17_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_17_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_17_V_read = ap_const_logic_1;
    } else {
        data_V_data_17_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_18_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_18_V_blk_n = data_V_data_18_V_empty_n.read();
    } else {
        data_V_data_18_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_18_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_18_V_read = ap_const_logic_1;
    } else {
        data_V_data_18_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_19_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_19_V_blk_n = data_V_data_19_V_empty_n.read();
    } else {
        data_V_data_19_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_19_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_19_V_read = ap_const_logic_1;
    } else {
        data_V_data_19_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_1_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_1_V_blk_n = data_V_data_1_V_empty_n.read();
    } else {
        data_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_1_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_1_V_read = ap_const_logic_1;
    } else {
        data_V_data_1_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_20_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_20_V_blk_n = data_V_data_20_V_empty_n.read();
    } else {
        data_V_data_20_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_20_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_20_V_read = ap_const_logic_1;
    } else {
        data_V_data_20_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_21_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_21_V_blk_n = data_V_data_21_V_empty_n.read();
    } else {
        data_V_data_21_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_21_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_21_V_read = ap_const_logic_1;
    } else {
        data_V_data_21_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_22_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_22_V_blk_n = data_V_data_22_V_empty_n.read();
    } else {
        data_V_data_22_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_22_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_22_V_read = ap_const_logic_1;
    } else {
        data_V_data_22_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_23_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_23_V_blk_n = data_V_data_23_V_empty_n.read();
    } else {
        data_V_data_23_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_23_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_23_V_read = ap_const_logic_1;
    } else {
        data_V_data_23_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_24_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_24_V_blk_n = data_V_data_24_V_empty_n.read();
    } else {
        data_V_data_24_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_24_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_24_V_read = ap_const_logic_1;
    } else {
        data_V_data_24_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_25_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_25_V_blk_n = data_V_data_25_V_empty_n.read();
    } else {
        data_V_data_25_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_25_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_25_V_read = ap_const_logic_1;
    } else {
        data_V_data_25_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_26_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_26_V_blk_n = data_V_data_26_V_empty_n.read();
    } else {
        data_V_data_26_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_26_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_26_V_read = ap_const_logic_1;
    } else {
        data_V_data_26_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_27_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_27_V_blk_n = data_V_data_27_V_empty_n.read();
    } else {
        data_V_data_27_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_27_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_27_V_read = ap_const_logic_1;
    } else {
        data_V_data_27_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_28_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_28_V_blk_n = data_V_data_28_V_empty_n.read();
    } else {
        data_V_data_28_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_28_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_28_V_read = ap_const_logic_1;
    } else {
        data_V_data_28_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_29_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_29_V_blk_n = data_V_data_29_V_empty_n.read();
    } else {
        data_V_data_29_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_29_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_29_V_read = ap_const_logic_1;
    } else {
        data_V_data_29_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_2_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_2_V_blk_n = data_V_data_2_V_empty_n.read();
    } else {
        data_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_2_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_2_V_read = ap_const_logic_1;
    } else {
        data_V_data_2_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_30_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_30_V_blk_n = data_V_data_30_V_empty_n.read();
    } else {
        data_V_data_30_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_30_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_30_V_read = ap_const_logic_1;
    } else {
        data_V_data_30_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_31_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_31_V_blk_n = data_V_data_31_V_empty_n.read();
    } else {
        data_V_data_31_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_31_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_31_V_read = ap_const_logic_1;
    } else {
        data_V_data_31_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_32_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_32_V_blk_n = data_V_data_32_V_empty_n.read();
    } else {
        data_V_data_32_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_32_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_32_V_read = ap_const_logic_1;
    } else {
        data_V_data_32_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_33_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_33_V_blk_n = data_V_data_33_V_empty_n.read();
    } else {
        data_V_data_33_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_33_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_33_V_read = ap_const_logic_1;
    } else {
        data_V_data_33_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_34_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_34_V_blk_n = data_V_data_34_V_empty_n.read();
    } else {
        data_V_data_34_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_34_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_34_V_read = ap_const_logic_1;
    } else {
        data_V_data_34_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_35_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_35_V_blk_n = data_V_data_35_V_empty_n.read();
    } else {
        data_V_data_35_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_35_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_35_V_read = ap_const_logic_1;
    } else {
        data_V_data_35_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_36_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_36_V_blk_n = data_V_data_36_V_empty_n.read();
    } else {
        data_V_data_36_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_36_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_36_V_read = ap_const_logic_1;
    } else {
        data_V_data_36_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_37_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_37_V_blk_n = data_V_data_37_V_empty_n.read();
    } else {
        data_V_data_37_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_37_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_37_V_read = ap_const_logic_1;
    } else {
        data_V_data_37_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_38_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_38_V_blk_n = data_V_data_38_V_empty_n.read();
    } else {
        data_V_data_38_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_38_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_38_V_read = ap_const_logic_1;
    } else {
        data_V_data_38_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_39_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_39_V_blk_n = data_V_data_39_V_empty_n.read();
    } else {
        data_V_data_39_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_39_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_39_V_read = ap_const_logic_1;
    } else {
        data_V_data_39_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_3_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_3_V_blk_n = data_V_data_3_V_empty_n.read();
    } else {
        data_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_3_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_3_V_read = ap_const_logic_1;
    } else {
        data_V_data_3_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_40_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_40_V_blk_n = data_V_data_40_V_empty_n.read();
    } else {
        data_V_data_40_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_40_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_40_V_read = ap_const_logic_1;
    } else {
        data_V_data_40_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_41_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_41_V_blk_n = data_V_data_41_V_empty_n.read();
    } else {
        data_V_data_41_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_41_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_41_V_read = ap_const_logic_1;
    } else {
        data_V_data_41_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_42_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_42_V_blk_n = data_V_data_42_V_empty_n.read();
    } else {
        data_V_data_42_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_42_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_42_V_read = ap_const_logic_1;
    } else {
        data_V_data_42_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_43_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_43_V_blk_n = data_V_data_43_V_empty_n.read();
    } else {
        data_V_data_43_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_43_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_43_V_read = ap_const_logic_1;
    } else {
        data_V_data_43_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_44_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_44_V_blk_n = data_V_data_44_V_empty_n.read();
    } else {
        data_V_data_44_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_44_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_44_V_read = ap_const_logic_1;
    } else {
        data_V_data_44_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_45_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_45_V_blk_n = data_V_data_45_V_empty_n.read();
    } else {
        data_V_data_45_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_45_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_45_V_read = ap_const_logic_1;
    } else {
        data_V_data_45_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_46_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_46_V_blk_n = data_V_data_46_V_empty_n.read();
    } else {
        data_V_data_46_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_46_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_46_V_read = ap_const_logic_1;
    } else {
        data_V_data_46_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_47_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_47_V_blk_n = data_V_data_47_V_empty_n.read();
    } else {
        data_V_data_47_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_47_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_47_V_read = ap_const_logic_1;
    } else {
        data_V_data_47_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_48_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_48_V_blk_n = data_V_data_48_V_empty_n.read();
    } else {
        data_V_data_48_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_48_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_48_V_read = ap_const_logic_1;
    } else {
        data_V_data_48_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_49_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_49_V_blk_n = data_V_data_49_V_empty_n.read();
    } else {
        data_V_data_49_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_49_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_49_V_read = ap_const_logic_1;
    } else {
        data_V_data_49_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_4_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_4_V_blk_n = data_V_data_4_V_empty_n.read();
    } else {
        data_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_4_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_4_V_read = ap_const_logic_1;
    } else {
        data_V_data_4_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_50_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_50_V_blk_n = data_V_data_50_V_empty_n.read();
    } else {
        data_V_data_50_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_50_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_50_V_read = ap_const_logic_1;
    } else {
        data_V_data_50_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_51_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_51_V_blk_n = data_V_data_51_V_empty_n.read();
    } else {
        data_V_data_51_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_51_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_51_V_read = ap_const_logic_1;
    } else {
        data_V_data_51_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_52_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_52_V_blk_n = data_V_data_52_V_empty_n.read();
    } else {
        data_V_data_52_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_52_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_52_V_read = ap_const_logic_1;
    } else {
        data_V_data_52_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_53_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_53_V_blk_n = data_V_data_53_V_empty_n.read();
    } else {
        data_V_data_53_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_53_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_53_V_read = ap_const_logic_1;
    } else {
        data_V_data_53_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_54_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_54_V_blk_n = data_V_data_54_V_empty_n.read();
    } else {
        data_V_data_54_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_54_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_54_V_read = ap_const_logic_1;
    } else {
        data_V_data_54_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_55_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_55_V_blk_n = data_V_data_55_V_empty_n.read();
    } else {
        data_V_data_55_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_55_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_55_V_read = ap_const_logic_1;
    } else {
        data_V_data_55_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_56_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_56_V_blk_n = data_V_data_56_V_empty_n.read();
    } else {
        data_V_data_56_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_56_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_56_V_read = ap_const_logic_1;
    } else {
        data_V_data_56_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_57_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_57_V_blk_n = data_V_data_57_V_empty_n.read();
    } else {
        data_V_data_57_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_57_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_57_V_read = ap_const_logic_1;
    } else {
        data_V_data_57_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_58_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_58_V_blk_n = data_V_data_58_V_empty_n.read();
    } else {
        data_V_data_58_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_58_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_58_V_read = ap_const_logic_1;
    } else {
        data_V_data_58_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_59_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_59_V_blk_n = data_V_data_59_V_empty_n.read();
    } else {
        data_V_data_59_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_59_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_59_V_read = ap_const_logic_1;
    } else {
        data_V_data_59_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_5_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_5_V_blk_n = data_V_data_5_V_empty_n.read();
    } else {
        data_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_5_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_5_V_read = ap_const_logic_1;
    } else {
        data_V_data_5_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_60_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_60_V_blk_n = data_V_data_60_V_empty_n.read();
    } else {
        data_V_data_60_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_60_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_60_V_read = ap_const_logic_1;
    } else {
        data_V_data_60_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_61_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_61_V_blk_n = data_V_data_61_V_empty_n.read();
    } else {
        data_V_data_61_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_61_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_61_V_read = ap_const_logic_1;
    } else {
        data_V_data_61_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_62_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_62_V_blk_n = data_V_data_62_V_empty_n.read();
    } else {
        data_V_data_62_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_62_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_62_V_read = ap_const_logic_1;
    } else {
        data_V_data_62_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_63_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_63_V_blk_n = data_V_data_63_V_empty_n.read();
    } else {
        data_V_data_63_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_63_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_63_V_read = ap_const_logic_1;
    } else {
        data_V_data_63_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_6_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_6_V_blk_n = data_V_data_6_V_empty_n.read();
    } else {
        data_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_6_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_6_V_read = ap_const_logic_1;
    } else {
        data_V_data_6_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_7_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_7_V_blk_n = data_V_data_7_V_empty_n.read();
    } else {
        data_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_7_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_7_V_read = ap_const_logic_1;
    } else {
        data_V_data_7_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_8_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_8_V_blk_n = data_V_data_8_V_empty_n.read();
    } else {
        data_V_data_8_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_8_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_8_V_read = ap_const_logic_1;
    } else {
        data_V_data_8_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_9_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        data_V_data_9_V_blk_n = data_V_data_9_V_empty_n.read();
    } else {
        data_V_data_9_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_data_V_data_9_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        data_V_data_9_V_read = ap_const_logic_1;
    } else {
        data_V_data_9_V_read = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_10_fu_1818_p2() {
    icmp_ln1494_10_fu_1818_p2 = (!data_V_data_10_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_10_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_11_fu_1910_p2() {
    icmp_ln1494_11_fu_1910_p2 = (!data_V_data_11_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_11_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_12_fu_2002_p2() {
    icmp_ln1494_12_fu_2002_p2 = (!data_V_data_12_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_12_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_13_fu_2094_p2() {
    icmp_ln1494_13_fu_2094_p2 = (!data_V_data_13_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_13_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_14_fu_2186_p2() {
    icmp_ln1494_14_fu_2186_p2 = (!data_V_data_14_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_14_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_15_fu_2278_p2() {
    icmp_ln1494_15_fu_2278_p2 = (!data_V_data_15_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_15_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_16_fu_2370_p2() {
    icmp_ln1494_16_fu_2370_p2 = (!data_V_data_16_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_16_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_17_fu_2462_p2() {
    icmp_ln1494_17_fu_2462_p2 = (!data_V_data_17_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_17_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_18_fu_2554_p2() {
    icmp_ln1494_18_fu_2554_p2 = (!data_V_data_18_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_18_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_19_fu_2646_p2() {
    icmp_ln1494_19_fu_2646_p2 = (!data_V_data_19_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_19_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_1_fu_990_p2() {
    icmp_ln1494_1_fu_990_p2 = (!data_V_data_1_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_1_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_20_fu_2738_p2() {
    icmp_ln1494_20_fu_2738_p2 = (!data_V_data_20_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_20_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_21_fu_2830_p2() {
    icmp_ln1494_21_fu_2830_p2 = (!data_V_data_21_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_21_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_22_fu_2922_p2() {
    icmp_ln1494_22_fu_2922_p2 = (!data_V_data_22_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_22_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_23_fu_3014_p2() {
    icmp_ln1494_23_fu_3014_p2 = (!data_V_data_23_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_23_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_24_fu_3106_p2() {
    icmp_ln1494_24_fu_3106_p2 = (!data_V_data_24_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_24_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_25_fu_3198_p2() {
    icmp_ln1494_25_fu_3198_p2 = (!data_V_data_25_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_25_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_26_fu_3290_p2() {
    icmp_ln1494_26_fu_3290_p2 = (!data_V_data_26_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_26_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_27_fu_3382_p2() {
    icmp_ln1494_27_fu_3382_p2 = (!data_V_data_27_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_27_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_28_fu_3474_p2() {
    icmp_ln1494_28_fu_3474_p2 = (!data_V_data_28_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_28_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_29_fu_3566_p2() {
    icmp_ln1494_29_fu_3566_p2 = (!data_V_data_29_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_29_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_2_fu_1082_p2() {
    icmp_ln1494_2_fu_1082_p2 = (!data_V_data_2_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_2_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_30_fu_3658_p2() {
    icmp_ln1494_30_fu_3658_p2 = (!data_V_data_30_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_30_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_31_fu_3750_p2() {
    icmp_ln1494_31_fu_3750_p2 = (!data_V_data_31_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_31_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_32_fu_3842_p2() {
    icmp_ln1494_32_fu_3842_p2 = (!data_V_data_32_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_32_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_33_fu_3934_p2() {
    icmp_ln1494_33_fu_3934_p2 = (!data_V_data_33_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_33_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_34_fu_4026_p2() {
    icmp_ln1494_34_fu_4026_p2 = (!data_V_data_34_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_34_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_35_fu_4118_p2() {
    icmp_ln1494_35_fu_4118_p2 = (!data_V_data_35_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_35_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_36_fu_4210_p2() {
    icmp_ln1494_36_fu_4210_p2 = (!data_V_data_36_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_36_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_37_fu_4302_p2() {
    icmp_ln1494_37_fu_4302_p2 = (!data_V_data_37_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_37_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_38_fu_4394_p2() {
    icmp_ln1494_38_fu_4394_p2 = (!data_V_data_38_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_38_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_39_fu_4486_p2() {
    icmp_ln1494_39_fu_4486_p2 = (!data_V_data_39_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_39_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_3_fu_1174_p2() {
    icmp_ln1494_3_fu_1174_p2 = (!data_V_data_3_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_3_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_40_fu_4578_p2() {
    icmp_ln1494_40_fu_4578_p2 = (!data_V_data_40_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_40_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_41_fu_4670_p2() {
    icmp_ln1494_41_fu_4670_p2 = (!data_V_data_41_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_41_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_42_fu_4762_p2() {
    icmp_ln1494_42_fu_4762_p2 = (!data_V_data_42_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_42_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_43_fu_4854_p2() {
    icmp_ln1494_43_fu_4854_p2 = (!data_V_data_43_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_43_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_44_fu_4946_p2() {
    icmp_ln1494_44_fu_4946_p2 = (!data_V_data_44_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_44_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_45_fu_5038_p2() {
    icmp_ln1494_45_fu_5038_p2 = (!data_V_data_45_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_45_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_46_fu_5130_p2() {
    icmp_ln1494_46_fu_5130_p2 = (!data_V_data_46_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_46_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_47_fu_5222_p2() {
    icmp_ln1494_47_fu_5222_p2 = (!data_V_data_47_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_47_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_48_fu_5314_p2() {
    icmp_ln1494_48_fu_5314_p2 = (!data_V_data_48_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_48_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_49_fu_5406_p2() {
    icmp_ln1494_49_fu_5406_p2 = (!data_V_data_49_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_49_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_4_fu_1266_p2() {
    icmp_ln1494_4_fu_1266_p2 = (!data_V_data_4_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_4_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_50_fu_5498_p2() {
    icmp_ln1494_50_fu_5498_p2 = (!data_V_data_50_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_50_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_51_fu_5590_p2() {
    icmp_ln1494_51_fu_5590_p2 = (!data_V_data_51_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_51_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_52_fu_5682_p2() {
    icmp_ln1494_52_fu_5682_p2 = (!data_V_data_52_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_52_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_53_fu_5774_p2() {
    icmp_ln1494_53_fu_5774_p2 = (!data_V_data_53_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_53_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_54_fu_5866_p2() {
    icmp_ln1494_54_fu_5866_p2 = (!data_V_data_54_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_54_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_55_fu_5958_p2() {
    icmp_ln1494_55_fu_5958_p2 = (!data_V_data_55_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_55_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_56_fu_6050_p2() {
    icmp_ln1494_56_fu_6050_p2 = (!data_V_data_56_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_56_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_57_fu_6142_p2() {
    icmp_ln1494_57_fu_6142_p2 = (!data_V_data_57_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_57_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_58_fu_6234_p2() {
    icmp_ln1494_58_fu_6234_p2 = (!data_V_data_58_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_58_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_59_fu_6326_p2() {
    icmp_ln1494_59_fu_6326_p2 = (!data_V_data_59_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_59_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_5_fu_1358_p2() {
    icmp_ln1494_5_fu_1358_p2 = (!data_V_data_5_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_5_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_60_fu_6418_p2() {
    icmp_ln1494_60_fu_6418_p2 = (!data_V_data_60_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_60_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_61_fu_6510_p2() {
    icmp_ln1494_61_fu_6510_p2 = (!data_V_data_61_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_61_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_62_fu_6602_p2() {
    icmp_ln1494_62_fu_6602_p2 = (!data_V_data_62_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_62_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_63_fu_6694_p2() {
    icmp_ln1494_63_fu_6694_p2 = (!data_V_data_63_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_63_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_6_fu_1450_p2() {
    icmp_ln1494_6_fu_1450_p2 = (!data_V_data_6_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_6_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_7_fu_1542_p2() {
    icmp_ln1494_7_fu_1542_p2 = (!data_V_data_7_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_7_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_8_fu_1634_p2() {
    icmp_ln1494_8_fu_1634_p2 = (!data_V_data_8_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_8_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_9_fu_1726_p2() {
    icmp_ln1494_9_fu_1726_p2 = (!data_V_data_9_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_9_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln1494_fu_898_p2() {
    icmp_ln1494_fu_898_p2 = (!data_V_data_0_V_dout.read().is_01() || !ap_const_lv16_0.is_01())? sc_lv<1>(): (sc_bigint<16>(data_V_data_0_V_dout.read()) > sc_bigint<16>(ap_const_lv16_0));
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_10_fu_1896_p2() {
    icmp_ln768_10_fu_1896_p2 = (!p_Result_5_s_fu_1880_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_s_fu_1880_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_11_fu_1988_p2() {
    icmp_ln768_11_fu_1988_p2 = (!p_Result_5_10_fu_1972_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_10_fu_1972_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_12_fu_2080_p2() {
    icmp_ln768_12_fu_2080_p2 = (!p_Result_5_11_fu_2064_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_11_fu_2064_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_13_fu_2172_p2() {
    icmp_ln768_13_fu_2172_p2 = (!p_Result_5_12_fu_2156_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_12_fu_2156_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_14_fu_2264_p2() {
    icmp_ln768_14_fu_2264_p2 = (!p_Result_5_13_fu_2248_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_13_fu_2248_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_15_fu_2356_p2() {
    icmp_ln768_15_fu_2356_p2 = (!p_Result_5_14_fu_2340_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_14_fu_2340_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_16_fu_2448_p2() {
    icmp_ln768_16_fu_2448_p2 = (!p_Result_5_15_fu_2432_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_15_fu_2432_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_17_fu_2540_p2() {
    icmp_ln768_17_fu_2540_p2 = (!p_Result_5_16_fu_2524_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_16_fu_2524_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_18_fu_2632_p2() {
    icmp_ln768_18_fu_2632_p2 = (!p_Result_5_17_fu_2616_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_17_fu_2616_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_19_fu_2724_p2() {
    icmp_ln768_19_fu_2724_p2 = (!p_Result_5_18_fu_2708_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_18_fu_2708_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_1_fu_1068_p2() {
    icmp_ln768_1_fu_1068_p2 = (!p_Result_5_1_fu_1052_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_1_fu_1052_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_20_fu_2816_p2() {
    icmp_ln768_20_fu_2816_p2 = (!p_Result_5_19_fu_2800_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_19_fu_2800_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_21_fu_2908_p2() {
    icmp_ln768_21_fu_2908_p2 = (!p_Result_5_20_fu_2892_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_20_fu_2892_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_22_fu_3000_p2() {
    icmp_ln768_22_fu_3000_p2 = (!p_Result_5_21_fu_2984_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_21_fu_2984_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_23_fu_3092_p2() {
    icmp_ln768_23_fu_3092_p2 = (!p_Result_5_22_fu_3076_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_22_fu_3076_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_24_fu_3184_p2() {
    icmp_ln768_24_fu_3184_p2 = (!p_Result_5_23_fu_3168_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_23_fu_3168_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_25_fu_3276_p2() {
    icmp_ln768_25_fu_3276_p2 = (!p_Result_5_24_fu_3260_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_24_fu_3260_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_26_fu_3368_p2() {
    icmp_ln768_26_fu_3368_p2 = (!p_Result_5_25_fu_3352_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_25_fu_3352_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_27_fu_3460_p2() {
    icmp_ln768_27_fu_3460_p2 = (!p_Result_5_26_fu_3444_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_26_fu_3444_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_28_fu_3552_p2() {
    icmp_ln768_28_fu_3552_p2 = (!p_Result_5_27_fu_3536_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_27_fu_3536_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_29_fu_3644_p2() {
    icmp_ln768_29_fu_3644_p2 = (!p_Result_5_28_fu_3628_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_28_fu_3628_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_2_fu_1160_p2() {
    icmp_ln768_2_fu_1160_p2 = (!p_Result_5_2_fu_1144_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_2_fu_1144_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_30_fu_3736_p2() {
    icmp_ln768_30_fu_3736_p2 = (!p_Result_5_29_fu_3720_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_29_fu_3720_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_31_fu_3828_p2() {
    icmp_ln768_31_fu_3828_p2 = (!p_Result_5_30_fu_3812_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_30_fu_3812_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_32_fu_3920_p2() {
    icmp_ln768_32_fu_3920_p2 = (!p_Result_5_31_fu_3904_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_31_fu_3904_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_33_fu_4012_p2() {
    icmp_ln768_33_fu_4012_p2 = (!p_Result_5_32_fu_3996_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_32_fu_3996_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_34_fu_4104_p2() {
    icmp_ln768_34_fu_4104_p2 = (!p_Result_5_33_fu_4088_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_33_fu_4088_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_35_fu_4196_p2() {
    icmp_ln768_35_fu_4196_p2 = (!p_Result_5_34_fu_4180_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_34_fu_4180_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_36_fu_4288_p2() {
    icmp_ln768_36_fu_4288_p2 = (!p_Result_5_35_fu_4272_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_35_fu_4272_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_37_fu_4380_p2() {
    icmp_ln768_37_fu_4380_p2 = (!p_Result_5_36_fu_4364_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_36_fu_4364_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_38_fu_4472_p2() {
    icmp_ln768_38_fu_4472_p2 = (!p_Result_5_37_fu_4456_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_37_fu_4456_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_39_fu_4564_p2() {
    icmp_ln768_39_fu_4564_p2 = (!p_Result_5_38_fu_4548_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_38_fu_4548_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_3_fu_1252_p2() {
    icmp_ln768_3_fu_1252_p2 = (!p_Result_5_3_fu_1236_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_3_fu_1236_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_40_fu_4656_p2() {
    icmp_ln768_40_fu_4656_p2 = (!p_Result_5_39_fu_4640_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_39_fu_4640_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_41_fu_4748_p2() {
    icmp_ln768_41_fu_4748_p2 = (!p_Result_5_40_fu_4732_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_40_fu_4732_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_42_fu_4840_p2() {
    icmp_ln768_42_fu_4840_p2 = (!p_Result_5_41_fu_4824_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_41_fu_4824_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_43_fu_4932_p2() {
    icmp_ln768_43_fu_4932_p2 = (!p_Result_5_42_fu_4916_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_42_fu_4916_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_44_fu_5024_p2() {
    icmp_ln768_44_fu_5024_p2 = (!p_Result_5_43_fu_5008_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_43_fu_5008_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_45_fu_5116_p2() {
    icmp_ln768_45_fu_5116_p2 = (!p_Result_5_44_fu_5100_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_44_fu_5100_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_46_fu_5208_p2() {
    icmp_ln768_46_fu_5208_p2 = (!p_Result_5_45_fu_5192_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_45_fu_5192_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_47_fu_5300_p2() {
    icmp_ln768_47_fu_5300_p2 = (!p_Result_5_46_fu_5284_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_46_fu_5284_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_48_fu_5392_p2() {
    icmp_ln768_48_fu_5392_p2 = (!p_Result_5_47_fu_5376_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_47_fu_5376_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_49_fu_5484_p2() {
    icmp_ln768_49_fu_5484_p2 = (!p_Result_5_48_fu_5468_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_48_fu_5468_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_4_fu_1344_p2() {
    icmp_ln768_4_fu_1344_p2 = (!p_Result_5_4_fu_1328_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_4_fu_1328_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_50_fu_5576_p2() {
    icmp_ln768_50_fu_5576_p2 = (!p_Result_5_49_fu_5560_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_49_fu_5560_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_51_fu_5668_p2() {
    icmp_ln768_51_fu_5668_p2 = (!p_Result_5_50_fu_5652_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_50_fu_5652_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_52_fu_5760_p2() {
    icmp_ln768_52_fu_5760_p2 = (!p_Result_5_51_fu_5744_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_51_fu_5744_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_53_fu_5852_p2() {
    icmp_ln768_53_fu_5852_p2 = (!p_Result_5_52_fu_5836_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_52_fu_5836_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_54_fu_5944_p2() {
    icmp_ln768_54_fu_5944_p2 = (!p_Result_5_53_fu_5928_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_53_fu_5928_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_55_fu_6036_p2() {
    icmp_ln768_55_fu_6036_p2 = (!p_Result_5_54_fu_6020_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_54_fu_6020_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_56_fu_6128_p2() {
    icmp_ln768_56_fu_6128_p2 = (!p_Result_5_55_fu_6112_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_55_fu_6112_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_57_fu_6220_p2() {
    icmp_ln768_57_fu_6220_p2 = (!p_Result_5_56_fu_6204_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_56_fu_6204_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_58_fu_6312_p2() {
    icmp_ln768_58_fu_6312_p2 = (!p_Result_5_57_fu_6296_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_57_fu_6296_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_59_fu_6404_p2() {
    icmp_ln768_59_fu_6404_p2 = (!p_Result_5_58_fu_6388_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_58_fu_6388_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_5_fu_1436_p2() {
    icmp_ln768_5_fu_1436_p2 = (!p_Result_5_5_fu_1420_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_5_fu_1420_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_60_fu_6496_p2() {
    icmp_ln768_60_fu_6496_p2 = (!p_Result_5_59_fu_6480_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_59_fu_6480_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_61_fu_6588_p2() {
    icmp_ln768_61_fu_6588_p2 = (!p_Result_5_60_fu_6572_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_60_fu_6572_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_62_fu_6680_p2() {
    icmp_ln768_62_fu_6680_p2 = (!p_Result_5_61_fu_6664_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_61_fu_6664_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_63_fu_6772_p2() {
    icmp_ln768_63_fu_6772_p2 = (!p_Result_5_62_fu_6756_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_62_fu_6756_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_6_fu_1528_p2() {
    icmp_ln768_6_fu_1528_p2 = (!p_Result_5_6_fu_1512_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_6_fu_1512_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_7_fu_1620_p2() {
    icmp_ln768_7_fu_1620_p2 = (!p_Result_5_7_fu_1604_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_7_fu_1604_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_8_fu_1712_p2() {
    icmp_ln768_8_fu_1712_p2 = (!p_Result_5_8_fu_1696_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_8_fu_1696_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_9_fu_1804_p2() {
    icmp_ln768_9_fu_1804_p2 = (!p_Result_5_9_fu_1788_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_9_fu_1788_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln768_fu_976_p2() {
    icmp_ln768_fu_976_p2 = (!p_Result_5_fu_960_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_fu_960_p4.read() == ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_10_fu_1890_p2() {
    icmp_ln879_10_fu_1890_p2 = (!p_Result_5_s_fu_1880_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_s_fu_1880_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_11_fu_1982_p2() {
    icmp_ln879_11_fu_1982_p2 = (!p_Result_5_10_fu_1972_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_10_fu_1972_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_12_fu_2074_p2() {
    icmp_ln879_12_fu_2074_p2 = (!p_Result_5_11_fu_2064_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_11_fu_2064_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_13_fu_2166_p2() {
    icmp_ln879_13_fu_2166_p2 = (!p_Result_5_12_fu_2156_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_12_fu_2156_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_14_fu_2258_p2() {
    icmp_ln879_14_fu_2258_p2 = (!p_Result_5_13_fu_2248_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_13_fu_2248_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_15_fu_2350_p2() {
    icmp_ln879_15_fu_2350_p2 = (!p_Result_5_14_fu_2340_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_14_fu_2340_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_16_fu_2442_p2() {
    icmp_ln879_16_fu_2442_p2 = (!p_Result_5_15_fu_2432_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_15_fu_2432_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_17_fu_2534_p2() {
    icmp_ln879_17_fu_2534_p2 = (!p_Result_5_16_fu_2524_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_16_fu_2524_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_18_fu_2626_p2() {
    icmp_ln879_18_fu_2626_p2 = (!p_Result_5_17_fu_2616_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_17_fu_2616_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_19_fu_2718_p2() {
    icmp_ln879_19_fu_2718_p2 = (!p_Result_5_18_fu_2708_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_18_fu_2708_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_1_fu_1062_p2() {
    icmp_ln879_1_fu_1062_p2 = (!p_Result_5_1_fu_1052_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_1_fu_1052_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_20_fu_2810_p2() {
    icmp_ln879_20_fu_2810_p2 = (!p_Result_5_19_fu_2800_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_19_fu_2800_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_21_fu_2902_p2() {
    icmp_ln879_21_fu_2902_p2 = (!p_Result_5_20_fu_2892_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_20_fu_2892_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_22_fu_2994_p2() {
    icmp_ln879_22_fu_2994_p2 = (!p_Result_5_21_fu_2984_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_21_fu_2984_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_23_fu_3086_p2() {
    icmp_ln879_23_fu_3086_p2 = (!p_Result_5_22_fu_3076_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_22_fu_3076_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_24_fu_3178_p2() {
    icmp_ln879_24_fu_3178_p2 = (!p_Result_5_23_fu_3168_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_23_fu_3168_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_25_fu_3270_p2() {
    icmp_ln879_25_fu_3270_p2 = (!p_Result_5_24_fu_3260_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_24_fu_3260_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_26_fu_3362_p2() {
    icmp_ln879_26_fu_3362_p2 = (!p_Result_5_25_fu_3352_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_25_fu_3352_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_27_fu_3454_p2() {
    icmp_ln879_27_fu_3454_p2 = (!p_Result_5_26_fu_3444_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_26_fu_3444_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_28_fu_3546_p2() {
    icmp_ln879_28_fu_3546_p2 = (!p_Result_5_27_fu_3536_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_27_fu_3536_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_29_fu_3638_p2() {
    icmp_ln879_29_fu_3638_p2 = (!p_Result_5_28_fu_3628_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_28_fu_3628_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_2_fu_1154_p2() {
    icmp_ln879_2_fu_1154_p2 = (!p_Result_5_2_fu_1144_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_2_fu_1144_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_30_fu_3730_p2() {
    icmp_ln879_30_fu_3730_p2 = (!p_Result_5_29_fu_3720_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_29_fu_3720_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_31_fu_3822_p2() {
    icmp_ln879_31_fu_3822_p2 = (!p_Result_5_30_fu_3812_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_30_fu_3812_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_32_fu_3914_p2() {
    icmp_ln879_32_fu_3914_p2 = (!p_Result_5_31_fu_3904_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_31_fu_3904_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_33_fu_4006_p2() {
    icmp_ln879_33_fu_4006_p2 = (!p_Result_5_32_fu_3996_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_32_fu_3996_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_34_fu_4098_p2() {
    icmp_ln879_34_fu_4098_p2 = (!p_Result_5_33_fu_4088_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_33_fu_4088_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_35_fu_4190_p2() {
    icmp_ln879_35_fu_4190_p2 = (!p_Result_5_34_fu_4180_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_34_fu_4180_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_36_fu_4282_p2() {
    icmp_ln879_36_fu_4282_p2 = (!p_Result_5_35_fu_4272_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_35_fu_4272_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_37_fu_4374_p2() {
    icmp_ln879_37_fu_4374_p2 = (!p_Result_5_36_fu_4364_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_36_fu_4364_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_38_fu_4466_p2() {
    icmp_ln879_38_fu_4466_p2 = (!p_Result_5_37_fu_4456_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_37_fu_4456_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_39_fu_4558_p2() {
    icmp_ln879_39_fu_4558_p2 = (!p_Result_5_38_fu_4548_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_38_fu_4548_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_3_fu_1246_p2() {
    icmp_ln879_3_fu_1246_p2 = (!p_Result_5_3_fu_1236_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_3_fu_1236_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_40_fu_4650_p2() {
    icmp_ln879_40_fu_4650_p2 = (!p_Result_5_39_fu_4640_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_39_fu_4640_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_41_fu_4742_p2() {
    icmp_ln879_41_fu_4742_p2 = (!p_Result_5_40_fu_4732_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_40_fu_4732_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_42_fu_4834_p2() {
    icmp_ln879_42_fu_4834_p2 = (!p_Result_5_41_fu_4824_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_41_fu_4824_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_43_fu_4926_p2() {
    icmp_ln879_43_fu_4926_p2 = (!p_Result_5_42_fu_4916_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_42_fu_4916_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_44_fu_5018_p2() {
    icmp_ln879_44_fu_5018_p2 = (!p_Result_5_43_fu_5008_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_43_fu_5008_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_45_fu_5110_p2() {
    icmp_ln879_45_fu_5110_p2 = (!p_Result_5_44_fu_5100_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_44_fu_5100_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_46_fu_5202_p2() {
    icmp_ln879_46_fu_5202_p2 = (!p_Result_5_45_fu_5192_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_45_fu_5192_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_47_fu_5294_p2() {
    icmp_ln879_47_fu_5294_p2 = (!p_Result_5_46_fu_5284_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_46_fu_5284_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_48_fu_5386_p2() {
    icmp_ln879_48_fu_5386_p2 = (!p_Result_5_47_fu_5376_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_47_fu_5376_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_49_fu_5478_p2() {
    icmp_ln879_49_fu_5478_p2 = (!p_Result_5_48_fu_5468_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_48_fu_5468_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_4_fu_1338_p2() {
    icmp_ln879_4_fu_1338_p2 = (!p_Result_5_4_fu_1328_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_4_fu_1328_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_50_fu_5570_p2() {
    icmp_ln879_50_fu_5570_p2 = (!p_Result_5_49_fu_5560_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_49_fu_5560_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_51_fu_5662_p2() {
    icmp_ln879_51_fu_5662_p2 = (!p_Result_5_50_fu_5652_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_50_fu_5652_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_52_fu_5754_p2() {
    icmp_ln879_52_fu_5754_p2 = (!p_Result_5_51_fu_5744_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_51_fu_5744_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_53_fu_5846_p2() {
    icmp_ln879_53_fu_5846_p2 = (!p_Result_5_52_fu_5836_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_52_fu_5836_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_54_fu_5938_p2() {
    icmp_ln879_54_fu_5938_p2 = (!p_Result_5_53_fu_5928_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_53_fu_5928_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_55_fu_6030_p2() {
    icmp_ln879_55_fu_6030_p2 = (!p_Result_5_54_fu_6020_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_54_fu_6020_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_56_fu_6122_p2() {
    icmp_ln879_56_fu_6122_p2 = (!p_Result_5_55_fu_6112_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_55_fu_6112_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_57_fu_6214_p2() {
    icmp_ln879_57_fu_6214_p2 = (!p_Result_5_56_fu_6204_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_56_fu_6204_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_58_fu_6306_p2() {
    icmp_ln879_58_fu_6306_p2 = (!p_Result_5_57_fu_6296_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_57_fu_6296_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_59_fu_6398_p2() {
    icmp_ln879_59_fu_6398_p2 = (!p_Result_5_58_fu_6388_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_58_fu_6388_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_5_fu_1430_p2() {
    icmp_ln879_5_fu_1430_p2 = (!p_Result_5_5_fu_1420_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_5_fu_1420_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_60_fu_6490_p2() {
    icmp_ln879_60_fu_6490_p2 = (!p_Result_5_59_fu_6480_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_59_fu_6480_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_61_fu_6582_p2() {
    icmp_ln879_61_fu_6582_p2 = (!p_Result_5_60_fu_6572_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_60_fu_6572_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_62_fu_6674_p2() {
    icmp_ln879_62_fu_6674_p2 = (!p_Result_5_61_fu_6664_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_61_fu_6664_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_63_fu_6766_p2() {
    icmp_ln879_63_fu_6766_p2 = (!p_Result_5_62_fu_6756_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_62_fu_6756_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_6_fu_1522_p2() {
    icmp_ln879_6_fu_1522_p2 = (!p_Result_5_6_fu_1512_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_6_fu_1512_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_7_fu_1614_p2() {
    icmp_ln879_7_fu_1614_p2 = (!p_Result_5_7_fu_1604_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_7_fu_1604_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_8_fu_1706_p2() {
    icmp_ln879_8_fu_1706_p2 = (!p_Result_5_8_fu_1696_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_8_fu_1696_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_9_fu_1798_p2() {
    icmp_ln879_9_fu_1798_p2 = (!p_Result_5_9_fu_1788_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_9_fu_1788_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_icmp_ln879_fu_970_p2() {
    icmp_ln879_fu_970_p2 = (!p_Result_5_fu_960_p4.read().is_01() || !ap_const_lv6_3F.is_01())? sc_lv<1>(): sc_lv<1>(p_Result_5_fu_960_p4.read() == ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_internal_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        internal_ap_ready = ap_const_logic_1;
    } else {
        internal_ap_ready = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_io_acc_block_signal_op1158() {
    io_acc_block_signal_op1158 = (res_V_data_0_V_full_n.read() & res_V_data_1_V_full_n.read() & res_V_data_2_V_full_n.read() & res_V_data_3_V_full_n.read() & res_V_data_4_V_full_n.read() & res_V_data_5_V_full_n.read() & res_V_data_6_V_full_n.read() & res_V_data_7_V_full_n.read() & res_V_data_8_V_full_n.read() & res_V_data_9_V_full_n.read() & res_V_data_10_V_full_n.read() & res_V_data_11_V_full_n.read() & res_V_data_12_V_full_n.read() & res_V_data_13_V_full_n.read() & res_V_data_14_V_full_n.read() & res_V_data_15_V_full_n.read() & res_V_data_16_V_full_n.read() & res_V_data_17_V_full_n.read() & res_V_data_18_V_full_n.read() & res_V_data_19_V_full_n.read() & res_V_data_20_V_full_n.read() & res_V_data_21_V_full_n.read() & res_V_data_22_V_full_n.read() & res_V_data_23_V_full_n.read() & res_V_data_24_V_full_n.read() & res_V_data_25_V_full_n.read() & res_V_data_26_V_full_n.read() & res_V_data_27_V_full_n.read() & res_V_data_28_V_full_n.read() & res_V_data_29_V_full_n.read() & res_V_data_30_V_full_n.read() & res_V_data_31_V_full_n.read() & res_V_data_32_V_full_n.read() & res_V_data_33_V_full_n.read() & res_V_data_34_V_full_n.read() & res_V_data_35_V_full_n.read() & res_V_data_36_V_full_n.read() & res_V_data_37_V_full_n.read() & res_V_data_38_V_full_n.read() & res_V_data_39_V_full_n.read() & res_V_data_40_V_full_n.read() & res_V_data_41_V_full_n.read() & res_V_data_42_V_full_n.read() & res_V_data_43_V_full_n.read() & res_V_data_44_V_full_n.read() & res_V_data_45_V_full_n.read() & res_V_data_46_V_full_n.read() & res_V_data_47_V_full_n.read() & res_V_data_48_V_full_n.read() & res_V_data_49_V_full_n.read() & res_V_data_50_V_full_n.read() & res_V_data_51_V_full_n.read() & res_V_data_52_V_full_n.read() & res_V_data_53_V_full_n.read() & res_V_data_54_V_full_n.read() & res_V_data_55_V_full_n.read() & res_V_data_56_V_full_n.read() & res_V_data_57_V_full_n.read() & res_V_data_58_V_full_n.read() & res_V_data_59_V_full_n.read() & res_V_data_60_V_full_n.read() & res_V_data_61_V_full_n.read() & res_V_data_62_V_full_n.read() & res_V_data_63_V_full_n.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_io_acc_block_signal_op133() {
    io_acc_block_signal_op133 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read() & data_V_data_8_V_empty_n.read() & data_V_data_9_V_empty_n.read() & data_V_data_10_V_empty_n.read() & data_V_data_11_V_empty_n.read() & data_V_data_12_V_empty_n.read() & data_V_data_13_V_empty_n.read() & data_V_data_14_V_empty_n.read() & data_V_data_15_V_empty_n.read() & data_V_data_16_V_empty_n.read() & data_V_data_17_V_empty_n.read() & data_V_data_18_V_empty_n.read() & data_V_data_19_V_empty_n.read() & data_V_data_20_V_empty_n.read() & data_V_data_21_V_empty_n.read() & data_V_data_22_V_empty_n.read() & data_V_data_23_V_empty_n.read() & data_V_data_24_V_empty_n.read() & data_V_data_25_V_empty_n.read() & data_V_data_26_V_empty_n.read() & data_V_data_27_V_empty_n.read() & data_V_data_28_V_empty_n.read() & data_V_data_29_V_empty_n.read() & data_V_data_30_V_empty_n.read() & data_V_data_31_V_empty_n.read() & data_V_data_32_V_empty_n.read() & data_V_data_33_V_empty_n.read() & data_V_data_34_V_empty_n.read() & data_V_data_35_V_empty_n.read() & data_V_data_36_V_empty_n.read() & data_V_data_37_V_empty_n.read() & data_V_data_38_V_empty_n.read() & data_V_data_39_V_empty_n.read() & data_V_data_40_V_empty_n.read() & data_V_data_41_V_empty_n.read() & data_V_data_42_V_empty_n.read() & data_V_data_43_V_empty_n.read() & data_V_data_44_V_empty_n.read() & data_V_data_45_V_empty_n.read() & data_V_data_46_V_empty_n.read() & data_V_data_47_V_empty_n.read() & data_V_data_48_V_empty_n.read() & data_V_data_49_V_empty_n.read() & data_V_data_50_V_empty_n.read() & data_V_data_51_V_empty_n.read() & data_V_data_52_V_empty_n.read() & data_V_data_53_V_empty_n.read() & data_V_data_54_V_empty_n.read() & data_V_data_55_V_empty_n.read() & data_V_data_56_V_empty_n.read() & data_V_data_57_V_empty_n.read() & data_V_data_58_V_empty_n.read() & data_V_data_59_V_empty_n.read() & data_V_data_60_V_empty_n.read() & data_V_data_61_V_empty_n.read() & data_V_data_62_V_empty_n.read() & data_V_data_63_V_empty_n.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_10_fu_1972_p4() {
    p_Result_5_10_fu_1972_p4 = data_V_data_11_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_11_fu_2064_p4() {
    p_Result_5_11_fu_2064_p4 = data_V_data_12_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_12_fu_2156_p4() {
    p_Result_5_12_fu_2156_p4 = data_V_data_13_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_13_fu_2248_p4() {
    p_Result_5_13_fu_2248_p4 = data_V_data_14_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_14_fu_2340_p4() {
    p_Result_5_14_fu_2340_p4 = data_V_data_15_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_15_fu_2432_p4() {
    p_Result_5_15_fu_2432_p4 = data_V_data_16_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_16_fu_2524_p4() {
    p_Result_5_16_fu_2524_p4 = data_V_data_17_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_17_fu_2616_p4() {
    p_Result_5_17_fu_2616_p4 = data_V_data_18_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_18_fu_2708_p4() {
    p_Result_5_18_fu_2708_p4 = data_V_data_19_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_19_fu_2800_p4() {
    p_Result_5_19_fu_2800_p4 = data_V_data_20_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_1_fu_1052_p4() {
    p_Result_5_1_fu_1052_p4 = data_V_data_1_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_20_fu_2892_p4() {
    p_Result_5_20_fu_2892_p4 = data_V_data_21_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_21_fu_2984_p4() {
    p_Result_5_21_fu_2984_p4 = data_V_data_22_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_22_fu_3076_p4() {
    p_Result_5_22_fu_3076_p4 = data_V_data_23_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_23_fu_3168_p4() {
    p_Result_5_23_fu_3168_p4 = data_V_data_24_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_24_fu_3260_p4() {
    p_Result_5_24_fu_3260_p4 = data_V_data_25_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_25_fu_3352_p4() {
    p_Result_5_25_fu_3352_p4 = data_V_data_26_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_26_fu_3444_p4() {
    p_Result_5_26_fu_3444_p4 = data_V_data_27_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_27_fu_3536_p4() {
    p_Result_5_27_fu_3536_p4 = data_V_data_28_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_28_fu_3628_p4() {
    p_Result_5_28_fu_3628_p4 = data_V_data_29_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_29_fu_3720_p4() {
    p_Result_5_29_fu_3720_p4 = data_V_data_30_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_2_fu_1144_p4() {
    p_Result_5_2_fu_1144_p4 = data_V_data_2_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_30_fu_3812_p4() {
    p_Result_5_30_fu_3812_p4 = data_V_data_31_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_31_fu_3904_p4() {
    p_Result_5_31_fu_3904_p4 = data_V_data_32_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_32_fu_3996_p4() {
    p_Result_5_32_fu_3996_p4 = data_V_data_33_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_33_fu_4088_p4() {
    p_Result_5_33_fu_4088_p4 = data_V_data_34_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_34_fu_4180_p4() {
    p_Result_5_34_fu_4180_p4 = data_V_data_35_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_35_fu_4272_p4() {
    p_Result_5_35_fu_4272_p4 = data_V_data_36_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_36_fu_4364_p4() {
    p_Result_5_36_fu_4364_p4 = data_V_data_37_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_37_fu_4456_p4() {
    p_Result_5_37_fu_4456_p4 = data_V_data_38_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_38_fu_4548_p4() {
    p_Result_5_38_fu_4548_p4 = data_V_data_39_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_39_fu_4640_p4() {
    p_Result_5_39_fu_4640_p4 = data_V_data_40_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_3_fu_1236_p4() {
    p_Result_5_3_fu_1236_p4 = data_V_data_3_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_40_fu_4732_p4() {
    p_Result_5_40_fu_4732_p4 = data_V_data_41_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_41_fu_4824_p4() {
    p_Result_5_41_fu_4824_p4 = data_V_data_42_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_42_fu_4916_p4() {
    p_Result_5_42_fu_4916_p4 = data_V_data_43_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_43_fu_5008_p4() {
    p_Result_5_43_fu_5008_p4 = data_V_data_44_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_44_fu_5100_p4() {
    p_Result_5_44_fu_5100_p4 = data_V_data_45_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_45_fu_5192_p4() {
    p_Result_5_45_fu_5192_p4 = data_V_data_46_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_46_fu_5284_p4() {
    p_Result_5_46_fu_5284_p4 = data_V_data_47_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_47_fu_5376_p4() {
    p_Result_5_47_fu_5376_p4 = data_V_data_48_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_48_fu_5468_p4() {
    p_Result_5_48_fu_5468_p4 = data_V_data_49_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_49_fu_5560_p4() {
    p_Result_5_49_fu_5560_p4 = data_V_data_50_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_4_fu_1328_p4() {
    p_Result_5_4_fu_1328_p4 = data_V_data_4_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_50_fu_5652_p4() {
    p_Result_5_50_fu_5652_p4 = data_V_data_51_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_51_fu_5744_p4() {
    p_Result_5_51_fu_5744_p4 = data_V_data_52_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_52_fu_5836_p4() {
    p_Result_5_52_fu_5836_p4 = data_V_data_53_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_53_fu_5928_p4() {
    p_Result_5_53_fu_5928_p4 = data_V_data_54_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_54_fu_6020_p4() {
    p_Result_5_54_fu_6020_p4 = data_V_data_55_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_55_fu_6112_p4() {
    p_Result_5_55_fu_6112_p4 = data_V_data_56_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_56_fu_6204_p4() {
    p_Result_5_56_fu_6204_p4 = data_V_data_57_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_57_fu_6296_p4() {
    p_Result_5_57_fu_6296_p4 = data_V_data_58_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_58_fu_6388_p4() {
    p_Result_5_58_fu_6388_p4 = data_V_data_59_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_59_fu_6480_p4() {
    p_Result_5_59_fu_6480_p4 = data_V_data_60_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_5_fu_1420_p4() {
    p_Result_5_5_fu_1420_p4 = data_V_data_5_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_60_fu_6572_p4() {
    p_Result_5_60_fu_6572_p4 = data_V_data_61_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_61_fu_6664_p4() {
    p_Result_5_61_fu_6664_p4 = data_V_data_62_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_62_fu_6756_p4() {
    p_Result_5_62_fu_6756_p4 = data_V_data_63_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_6_fu_1512_p4() {
    p_Result_5_6_fu_1512_p4 = data_V_data_6_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_7_fu_1604_p4() {
    p_Result_5_7_fu_1604_p4 = data_V_data_7_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_8_fu_1696_p4() {
    p_Result_5_8_fu_1696_p4 = data_V_data_8_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_9_fu_1788_p4() {
    p_Result_5_9_fu_1788_p4 = data_V_data_9_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_fu_960_p4() {
    p_Result_5_fu_960_p4 = data_V_data_0_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_p_Result_5_s_fu_1880_p4() {
    p_Result_5_s_fu_1880_p4 = data_V_data_10_V_dout.read().range(15, 10);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_real_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_full_n.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()))) {
        real_start = ap_const_logic_0;
    } else {
        real_start = ap_start.read();
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_0_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_0_V_blk_n = res_V_data_0_V_full_n.read();
    } else {
        res_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_0_V_din() {
    res_V_data_0_V_din = (!icmp_ln1494_fu_898_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_fu_898_p2.read()[0].to_bool())? select_ln340_fu_6786_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_0_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_0_V_write = ap_const_logic_1;
    } else {
        res_V_data_0_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_10_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_10_V_blk_n = res_V_data_10_V_full_n.read();
    } else {
        res_V_data_10_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_10_V_din() {
    res_V_data_10_V_din = (!icmp_ln1494_10_fu_1818_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_10_fu_1818_p2.read()[0].to_bool())? select_ln340_14_fu_6956_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_10_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_10_V_write = ap_const_logic_1;
    } else {
        res_V_data_10_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_11_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_11_V_blk_n = res_V_data_11_V_full_n.read();
    } else {
        res_V_data_11_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_11_V_din() {
    res_V_data_11_V_din = (!icmp_ln1494_11_fu_1910_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_11_fu_1910_p2.read()[0].to_bool())? select_ln340_15_fu_6973_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_11_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_11_V_write = ap_const_logic_1;
    } else {
        res_V_data_11_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_12_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_12_V_blk_n = res_V_data_12_V_full_n.read();
    } else {
        res_V_data_12_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_12_V_din() {
    res_V_data_12_V_din = (!icmp_ln1494_12_fu_2002_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_12_fu_2002_p2.read()[0].to_bool())? select_ln340_16_fu_6990_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_12_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_12_V_write = ap_const_logic_1;
    } else {
        res_V_data_12_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_13_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_13_V_blk_n = res_V_data_13_V_full_n.read();
    } else {
        res_V_data_13_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_13_V_din() {
    res_V_data_13_V_din = (!icmp_ln1494_13_fu_2094_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_13_fu_2094_p2.read()[0].to_bool())? select_ln340_17_fu_7007_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_13_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_13_V_write = ap_const_logic_1;
    } else {
        res_V_data_13_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_14_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_14_V_blk_n = res_V_data_14_V_full_n.read();
    } else {
        res_V_data_14_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_14_V_din() {
    res_V_data_14_V_din = (!icmp_ln1494_14_fu_2186_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_14_fu_2186_p2.read()[0].to_bool())? select_ln340_18_fu_7024_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_14_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_14_V_write = ap_const_logic_1;
    } else {
        res_V_data_14_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_15_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_15_V_blk_n = res_V_data_15_V_full_n.read();
    } else {
        res_V_data_15_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_15_V_din() {
    res_V_data_15_V_din = (!icmp_ln1494_15_fu_2278_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_15_fu_2278_p2.read()[0].to_bool())? select_ln340_19_fu_7041_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_15_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_15_V_write = ap_const_logic_1;
    } else {
        res_V_data_15_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_16_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_16_V_blk_n = res_V_data_16_V_full_n.read();
    } else {
        res_V_data_16_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_16_V_din() {
    res_V_data_16_V_din = (!icmp_ln1494_16_fu_2370_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_16_fu_2370_p2.read()[0].to_bool())? select_ln340_20_fu_7058_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_16_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_16_V_write = ap_const_logic_1;
    } else {
        res_V_data_16_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_17_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_17_V_blk_n = res_V_data_17_V_full_n.read();
    } else {
        res_V_data_17_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_17_V_din() {
    res_V_data_17_V_din = (!icmp_ln1494_17_fu_2462_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_17_fu_2462_p2.read()[0].to_bool())? select_ln340_21_fu_7075_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_17_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_17_V_write = ap_const_logic_1;
    } else {
        res_V_data_17_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_18_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_18_V_blk_n = res_V_data_18_V_full_n.read();
    } else {
        res_V_data_18_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_18_V_din() {
    res_V_data_18_V_din = (!icmp_ln1494_18_fu_2554_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_18_fu_2554_p2.read()[0].to_bool())? select_ln340_22_fu_7092_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_18_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_18_V_write = ap_const_logic_1;
    } else {
        res_V_data_18_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_19_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_19_V_blk_n = res_V_data_19_V_full_n.read();
    } else {
        res_V_data_19_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_19_V_din() {
    res_V_data_19_V_din = (!icmp_ln1494_19_fu_2646_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_19_fu_2646_p2.read()[0].to_bool())? select_ln340_23_fu_7109_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_19_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_19_V_write = ap_const_logic_1;
    } else {
        res_V_data_19_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_1_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_1_V_blk_n = res_V_data_1_V_full_n.read();
    } else {
        res_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_1_V_din() {
    res_V_data_1_V_din = (!icmp_ln1494_1_fu_990_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_1_fu_990_p2.read()[0].to_bool())? select_ln340_5_fu_6803_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_1_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_1_V_write = ap_const_logic_1;
    } else {
        res_V_data_1_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_20_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_20_V_blk_n = res_V_data_20_V_full_n.read();
    } else {
        res_V_data_20_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_20_V_din() {
    res_V_data_20_V_din = (!icmp_ln1494_20_fu_2738_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_20_fu_2738_p2.read()[0].to_bool())? select_ln340_24_fu_7126_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_20_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_20_V_write = ap_const_logic_1;
    } else {
        res_V_data_20_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_21_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_21_V_blk_n = res_V_data_21_V_full_n.read();
    } else {
        res_V_data_21_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_21_V_din() {
    res_V_data_21_V_din = (!icmp_ln1494_21_fu_2830_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_21_fu_2830_p2.read()[0].to_bool())? select_ln340_25_fu_7143_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_21_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_21_V_write = ap_const_logic_1;
    } else {
        res_V_data_21_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_22_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_22_V_blk_n = res_V_data_22_V_full_n.read();
    } else {
        res_V_data_22_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_22_V_din() {
    res_V_data_22_V_din = (!icmp_ln1494_22_fu_2922_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_22_fu_2922_p2.read()[0].to_bool())? select_ln340_26_fu_7160_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_22_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_22_V_write = ap_const_logic_1;
    } else {
        res_V_data_22_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_23_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_23_V_blk_n = res_V_data_23_V_full_n.read();
    } else {
        res_V_data_23_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_23_V_din() {
    res_V_data_23_V_din = (!icmp_ln1494_23_fu_3014_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_23_fu_3014_p2.read()[0].to_bool())? select_ln340_27_fu_7177_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_23_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_23_V_write = ap_const_logic_1;
    } else {
        res_V_data_23_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_24_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_24_V_blk_n = res_V_data_24_V_full_n.read();
    } else {
        res_V_data_24_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_24_V_din() {
    res_V_data_24_V_din = (!icmp_ln1494_24_fu_3106_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_24_fu_3106_p2.read()[0].to_bool())? select_ln340_28_fu_7194_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_24_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_24_V_write = ap_const_logic_1;
    } else {
        res_V_data_24_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_25_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_25_V_blk_n = res_V_data_25_V_full_n.read();
    } else {
        res_V_data_25_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_25_V_din() {
    res_V_data_25_V_din = (!icmp_ln1494_25_fu_3198_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_25_fu_3198_p2.read()[0].to_bool())? select_ln340_29_fu_7211_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_25_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_25_V_write = ap_const_logic_1;
    } else {
        res_V_data_25_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_26_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_26_V_blk_n = res_V_data_26_V_full_n.read();
    } else {
        res_V_data_26_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_26_V_din() {
    res_V_data_26_V_din = (!icmp_ln1494_26_fu_3290_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_26_fu_3290_p2.read()[0].to_bool())? select_ln340_30_fu_7228_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_26_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_26_V_write = ap_const_logic_1;
    } else {
        res_V_data_26_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_27_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_27_V_blk_n = res_V_data_27_V_full_n.read();
    } else {
        res_V_data_27_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_27_V_din() {
    res_V_data_27_V_din = (!icmp_ln1494_27_fu_3382_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_27_fu_3382_p2.read()[0].to_bool())? select_ln340_31_fu_7245_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_27_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_27_V_write = ap_const_logic_1;
    } else {
        res_V_data_27_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_28_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_28_V_blk_n = res_V_data_28_V_full_n.read();
    } else {
        res_V_data_28_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_28_V_din() {
    res_V_data_28_V_din = (!icmp_ln1494_28_fu_3474_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_28_fu_3474_p2.read()[0].to_bool())? select_ln340_32_fu_7262_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_28_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_28_V_write = ap_const_logic_1;
    } else {
        res_V_data_28_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_29_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_29_V_blk_n = res_V_data_29_V_full_n.read();
    } else {
        res_V_data_29_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_29_V_din() {
    res_V_data_29_V_din = (!icmp_ln1494_29_fu_3566_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_29_fu_3566_p2.read()[0].to_bool())? select_ln340_33_fu_7279_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_29_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_29_V_write = ap_const_logic_1;
    } else {
        res_V_data_29_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_2_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_2_V_blk_n = res_V_data_2_V_full_n.read();
    } else {
        res_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_2_V_din() {
    res_V_data_2_V_din = (!icmp_ln1494_2_fu_1082_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_2_fu_1082_p2.read()[0].to_bool())? select_ln340_6_fu_6820_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_2_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_2_V_write = ap_const_logic_1;
    } else {
        res_V_data_2_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_30_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_30_V_blk_n = res_V_data_30_V_full_n.read();
    } else {
        res_V_data_30_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_30_V_din() {
    res_V_data_30_V_din = (!icmp_ln1494_30_fu_3658_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_30_fu_3658_p2.read()[0].to_bool())? select_ln340_34_fu_7296_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_30_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_30_V_write = ap_const_logic_1;
    } else {
        res_V_data_30_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_31_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_31_V_blk_n = res_V_data_31_V_full_n.read();
    } else {
        res_V_data_31_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_31_V_din() {
    res_V_data_31_V_din = (!icmp_ln1494_31_fu_3750_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_31_fu_3750_p2.read()[0].to_bool())? select_ln340_35_fu_7313_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_31_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_31_V_write = ap_const_logic_1;
    } else {
        res_V_data_31_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_32_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_32_V_blk_n = res_V_data_32_V_full_n.read();
    } else {
        res_V_data_32_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_32_V_din() {
    res_V_data_32_V_din = (!icmp_ln1494_32_fu_3842_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_32_fu_3842_p2.read()[0].to_bool())? select_ln340_36_fu_7330_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_32_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_32_V_write = ap_const_logic_1;
    } else {
        res_V_data_32_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_33_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_33_V_blk_n = res_V_data_33_V_full_n.read();
    } else {
        res_V_data_33_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_33_V_din() {
    res_V_data_33_V_din = (!icmp_ln1494_33_fu_3934_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_33_fu_3934_p2.read()[0].to_bool())? select_ln340_37_fu_7347_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_33_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_33_V_write = ap_const_logic_1;
    } else {
        res_V_data_33_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_34_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_34_V_blk_n = res_V_data_34_V_full_n.read();
    } else {
        res_V_data_34_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_34_V_din() {
    res_V_data_34_V_din = (!icmp_ln1494_34_fu_4026_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_34_fu_4026_p2.read()[0].to_bool())? select_ln340_38_fu_7364_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_34_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_34_V_write = ap_const_logic_1;
    } else {
        res_V_data_34_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_35_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_35_V_blk_n = res_V_data_35_V_full_n.read();
    } else {
        res_V_data_35_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_35_V_din() {
    res_V_data_35_V_din = (!icmp_ln1494_35_fu_4118_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_35_fu_4118_p2.read()[0].to_bool())? select_ln340_39_fu_7381_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_35_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_35_V_write = ap_const_logic_1;
    } else {
        res_V_data_35_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_36_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_36_V_blk_n = res_V_data_36_V_full_n.read();
    } else {
        res_V_data_36_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_36_V_din() {
    res_V_data_36_V_din = (!icmp_ln1494_36_fu_4210_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_36_fu_4210_p2.read()[0].to_bool())? select_ln340_40_fu_7398_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_36_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_36_V_write = ap_const_logic_1;
    } else {
        res_V_data_36_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_37_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_37_V_blk_n = res_V_data_37_V_full_n.read();
    } else {
        res_V_data_37_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_37_V_din() {
    res_V_data_37_V_din = (!icmp_ln1494_37_fu_4302_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_37_fu_4302_p2.read()[0].to_bool())? select_ln340_41_fu_7415_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_37_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_37_V_write = ap_const_logic_1;
    } else {
        res_V_data_37_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_38_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_38_V_blk_n = res_V_data_38_V_full_n.read();
    } else {
        res_V_data_38_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_38_V_din() {
    res_V_data_38_V_din = (!icmp_ln1494_38_fu_4394_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_38_fu_4394_p2.read()[0].to_bool())? select_ln340_42_fu_7432_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_38_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_38_V_write = ap_const_logic_1;
    } else {
        res_V_data_38_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_39_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_39_V_blk_n = res_V_data_39_V_full_n.read();
    } else {
        res_V_data_39_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_39_V_din() {
    res_V_data_39_V_din = (!icmp_ln1494_39_fu_4486_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_39_fu_4486_p2.read()[0].to_bool())? select_ln340_43_fu_7449_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_39_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_39_V_write = ap_const_logic_1;
    } else {
        res_V_data_39_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_3_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_3_V_blk_n = res_V_data_3_V_full_n.read();
    } else {
        res_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_3_V_din() {
    res_V_data_3_V_din = (!icmp_ln1494_3_fu_1174_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_3_fu_1174_p2.read()[0].to_bool())? select_ln340_7_fu_6837_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_3_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_3_V_write = ap_const_logic_1;
    } else {
        res_V_data_3_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_40_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_40_V_blk_n = res_V_data_40_V_full_n.read();
    } else {
        res_V_data_40_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_40_V_din() {
    res_V_data_40_V_din = (!icmp_ln1494_40_fu_4578_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_40_fu_4578_p2.read()[0].to_bool())? select_ln340_44_fu_7466_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_40_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_40_V_write = ap_const_logic_1;
    } else {
        res_V_data_40_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_41_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_41_V_blk_n = res_V_data_41_V_full_n.read();
    } else {
        res_V_data_41_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_41_V_din() {
    res_V_data_41_V_din = (!icmp_ln1494_41_fu_4670_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_41_fu_4670_p2.read()[0].to_bool())? select_ln340_45_fu_7483_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_41_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_41_V_write = ap_const_logic_1;
    } else {
        res_V_data_41_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_42_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_42_V_blk_n = res_V_data_42_V_full_n.read();
    } else {
        res_V_data_42_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_42_V_din() {
    res_V_data_42_V_din = (!icmp_ln1494_42_fu_4762_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_42_fu_4762_p2.read()[0].to_bool())? select_ln340_46_fu_7500_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_42_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_42_V_write = ap_const_logic_1;
    } else {
        res_V_data_42_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_43_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_43_V_blk_n = res_V_data_43_V_full_n.read();
    } else {
        res_V_data_43_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_43_V_din() {
    res_V_data_43_V_din = (!icmp_ln1494_43_fu_4854_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_43_fu_4854_p2.read()[0].to_bool())? select_ln340_47_fu_7517_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_43_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_43_V_write = ap_const_logic_1;
    } else {
        res_V_data_43_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_44_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_44_V_blk_n = res_V_data_44_V_full_n.read();
    } else {
        res_V_data_44_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_44_V_din() {
    res_V_data_44_V_din = (!icmp_ln1494_44_fu_4946_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_44_fu_4946_p2.read()[0].to_bool())? select_ln340_48_fu_7534_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_44_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_44_V_write = ap_const_logic_1;
    } else {
        res_V_data_44_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_45_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_45_V_blk_n = res_V_data_45_V_full_n.read();
    } else {
        res_V_data_45_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_45_V_din() {
    res_V_data_45_V_din = (!icmp_ln1494_45_fu_5038_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_45_fu_5038_p2.read()[0].to_bool())? select_ln340_49_fu_7551_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_45_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_45_V_write = ap_const_logic_1;
    } else {
        res_V_data_45_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_46_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_46_V_blk_n = res_V_data_46_V_full_n.read();
    } else {
        res_V_data_46_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_46_V_din() {
    res_V_data_46_V_din = (!icmp_ln1494_46_fu_5130_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_46_fu_5130_p2.read()[0].to_bool())? select_ln340_50_fu_7568_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_46_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_46_V_write = ap_const_logic_1;
    } else {
        res_V_data_46_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_47_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_47_V_blk_n = res_V_data_47_V_full_n.read();
    } else {
        res_V_data_47_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_47_V_din() {
    res_V_data_47_V_din = (!icmp_ln1494_47_fu_5222_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_47_fu_5222_p2.read()[0].to_bool())? select_ln340_51_fu_7585_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_47_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_47_V_write = ap_const_logic_1;
    } else {
        res_V_data_47_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_48_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_48_V_blk_n = res_V_data_48_V_full_n.read();
    } else {
        res_V_data_48_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_48_V_din() {
    res_V_data_48_V_din = (!icmp_ln1494_48_fu_5314_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_48_fu_5314_p2.read()[0].to_bool())? select_ln340_52_fu_7602_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_48_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_48_V_write = ap_const_logic_1;
    } else {
        res_V_data_48_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_49_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_49_V_blk_n = res_V_data_49_V_full_n.read();
    } else {
        res_V_data_49_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_49_V_din() {
    res_V_data_49_V_din = (!icmp_ln1494_49_fu_5406_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_49_fu_5406_p2.read()[0].to_bool())? select_ln340_53_fu_7619_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_49_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_49_V_write = ap_const_logic_1;
    } else {
        res_V_data_49_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_4_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_4_V_blk_n = res_V_data_4_V_full_n.read();
    } else {
        res_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_4_V_din() {
    res_V_data_4_V_din = (!icmp_ln1494_4_fu_1266_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_4_fu_1266_p2.read()[0].to_bool())? select_ln340_8_fu_6854_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_4_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_4_V_write = ap_const_logic_1;
    } else {
        res_V_data_4_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_50_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_50_V_blk_n = res_V_data_50_V_full_n.read();
    } else {
        res_V_data_50_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_50_V_din() {
    res_V_data_50_V_din = (!icmp_ln1494_50_fu_5498_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_50_fu_5498_p2.read()[0].to_bool())? select_ln340_54_fu_7636_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_50_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_50_V_write = ap_const_logic_1;
    } else {
        res_V_data_50_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_51_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_51_V_blk_n = res_V_data_51_V_full_n.read();
    } else {
        res_V_data_51_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_51_V_din() {
    res_V_data_51_V_din = (!icmp_ln1494_51_fu_5590_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_51_fu_5590_p2.read()[0].to_bool())? select_ln340_55_fu_7653_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_51_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_51_V_write = ap_const_logic_1;
    } else {
        res_V_data_51_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_52_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_52_V_blk_n = res_V_data_52_V_full_n.read();
    } else {
        res_V_data_52_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_52_V_din() {
    res_V_data_52_V_din = (!icmp_ln1494_52_fu_5682_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_52_fu_5682_p2.read()[0].to_bool())? select_ln340_56_fu_7670_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_52_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_52_V_write = ap_const_logic_1;
    } else {
        res_V_data_52_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_53_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_53_V_blk_n = res_V_data_53_V_full_n.read();
    } else {
        res_V_data_53_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_53_V_din() {
    res_V_data_53_V_din = (!icmp_ln1494_53_fu_5774_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_53_fu_5774_p2.read()[0].to_bool())? select_ln340_57_fu_7687_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_53_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_53_V_write = ap_const_logic_1;
    } else {
        res_V_data_53_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_54_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_54_V_blk_n = res_V_data_54_V_full_n.read();
    } else {
        res_V_data_54_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_54_V_din() {
    res_V_data_54_V_din = (!icmp_ln1494_54_fu_5866_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_54_fu_5866_p2.read()[0].to_bool())? select_ln340_58_fu_7704_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_54_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_54_V_write = ap_const_logic_1;
    } else {
        res_V_data_54_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_55_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_55_V_blk_n = res_V_data_55_V_full_n.read();
    } else {
        res_V_data_55_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_55_V_din() {
    res_V_data_55_V_din = (!icmp_ln1494_55_fu_5958_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_55_fu_5958_p2.read()[0].to_bool())? select_ln340_59_fu_7721_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_55_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_55_V_write = ap_const_logic_1;
    } else {
        res_V_data_55_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_56_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_56_V_blk_n = res_V_data_56_V_full_n.read();
    } else {
        res_V_data_56_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_56_V_din() {
    res_V_data_56_V_din = (!icmp_ln1494_56_fu_6050_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_56_fu_6050_p2.read()[0].to_bool())? select_ln340_60_fu_7738_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_56_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_56_V_write = ap_const_logic_1;
    } else {
        res_V_data_56_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_57_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_57_V_blk_n = res_V_data_57_V_full_n.read();
    } else {
        res_V_data_57_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_57_V_din() {
    res_V_data_57_V_din = (!icmp_ln1494_57_fu_6142_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_57_fu_6142_p2.read()[0].to_bool())? select_ln340_61_fu_7755_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_57_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_57_V_write = ap_const_logic_1;
    } else {
        res_V_data_57_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_58_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_58_V_blk_n = res_V_data_58_V_full_n.read();
    } else {
        res_V_data_58_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_58_V_din() {
    res_V_data_58_V_din = (!icmp_ln1494_58_fu_6234_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_58_fu_6234_p2.read()[0].to_bool())? select_ln340_62_fu_7772_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_58_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_58_V_write = ap_const_logic_1;
    } else {
        res_V_data_58_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_59_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_59_V_blk_n = res_V_data_59_V_full_n.read();
    } else {
        res_V_data_59_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_59_V_din() {
    res_V_data_59_V_din = (!icmp_ln1494_59_fu_6326_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_59_fu_6326_p2.read()[0].to_bool())? select_ln340_63_fu_7789_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_59_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_59_V_write = ap_const_logic_1;
    } else {
        res_V_data_59_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_5_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_5_V_blk_n = res_V_data_5_V_full_n.read();
    } else {
        res_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_5_V_din() {
    res_V_data_5_V_din = (!icmp_ln1494_5_fu_1358_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_5_fu_1358_p2.read()[0].to_bool())? select_ln340_9_fu_6871_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_5_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_5_V_write = ap_const_logic_1;
    } else {
        res_V_data_5_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_60_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_60_V_blk_n = res_V_data_60_V_full_n.read();
    } else {
        res_V_data_60_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_60_V_din() {
    res_V_data_60_V_din = (!icmp_ln1494_60_fu_6418_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_60_fu_6418_p2.read()[0].to_bool())? select_ln340_64_fu_7806_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_60_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_60_V_write = ap_const_logic_1;
    } else {
        res_V_data_60_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_61_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_61_V_blk_n = res_V_data_61_V_full_n.read();
    } else {
        res_V_data_61_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_61_V_din() {
    res_V_data_61_V_din = (!icmp_ln1494_61_fu_6510_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_61_fu_6510_p2.read()[0].to_bool())? select_ln340_65_fu_7823_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_61_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_61_V_write = ap_const_logic_1;
    } else {
        res_V_data_61_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_62_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_62_V_blk_n = res_V_data_62_V_full_n.read();
    } else {
        res_V_data_62_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_62_V_din() {
    res_V_data_62_V_din = (!icmp_ln1494_62_fu_6602_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_62_fu_6602_p2.read()[0].to_bool())? select_ln340_66_fu_7840_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_62_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_62_V_write = ap_const_logic_1;
    } else {
        res_V_data_62_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_63_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_63_V_blk_n = res_V_data_63_V_full_n.read();
    } else {
        res_V_data_63_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_63_V_din() {
    res_V_data_63_V_din = (!icmp_ln1494_63_fu_6694_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_63_fu_6694_p2.read()[0].to_bool())? select_ln340_67_fu_7857_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_63_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_63_V_write = ap_const_logic_1;
    } else {
        res_V_data_63_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_6_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_6_V_blk_n = res_V_data_6_V_full_n.read();
    } else {
        res_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_6_V_din() {
    res_V_data_6_V_din = (!icmp_ln1494_6_fu_1450_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_6_fu_1450_p2.read()[0].to_bool())? select_ln340_10_fu_6888_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_6_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_6_V_write = ap_const_logic_1;
    } else {
        res_V_data_6_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_7_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_7_V_blk_n = res_V_data_7_V_full_n.read();
    } else {
        res_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_7_V_din() {
    res_V_data_7_V_din = (!icmp_ln1494_7_fu_1542_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_7_fu_1542_p2.read()[0].to_bool())? select_ln340_11_fu_6905_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_7_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_7_V_write = ap_const_logic_1;
    } else {
        res_V_data_7_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_8_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_8_V_blk_n = res_V_data_8_V_full_n.read();
    } else {
        res_V_data_8_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_8_V_din() {
    res_V_data_8_V_din = (!icmp_ln1494_8_fu_1634_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_8_fu_1634_p2.read()[0].to_bool())? select_ln340_12_fu_6922_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_8_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_8_V_write = ap_const_logic_1;
    } else {
        res_V_data_8_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_9_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        res_V_data_9_V_blk_n = res_V_data_9_V_full_n.read();
    } else {
        res_V_data_9_V_blk_n = ap_const_logic_1;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_9_V_din() {
    res_V_data_9_V_din = (!icmp_ln1494_9_fu_1726_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1494_9_fu_1726_p2.read()[0].to_bool())? select_ln340_13_fu_6939_p3.read(): ap_const_lv6_0);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_res_V_data_9_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op133.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1158.read())))) {
        res_V_data_9_V_write = ap_const_logic_1;
    } else {
        res_V_data_9_V_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_10_fu_6888_p3() {
    select_ln340_10_fu_6888_p3 = (!select_ln777_6_fu_1534_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_6_fu_1534_p3.read()[0].to_bool())? add_ln415_6_fu_1486_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_11_fu_6905_p3() {
    select_ln340_11_fu_6905_p3 = (!select_ln777_7_fu_1626_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_7_fu_1626_p3.read()[0].to_bool())? add_ln415_7_fu_1578_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_12_fu_6922_p3() {
    select_ln340_12_fu_6922_p3 = (!select_ln777_8_fu_1718_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_8_fu_1718_p3.read()[0].to_bool())? add_ln415_8_fu_1670_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_13_fu_6939_p3() {
    select_ln340_13_fu_6939_p3 = (!select_ln777_9_fu_1810_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_9_fu_1810_p3.read()[0].to_bool())? add_ln415_9_fu_1762_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_14_fu_6956_p3() {
    select_ln340_14_fu_6956_p3 = (!select_ln777_10_fu_1902_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_10_fu_1902_p3.read()[0].to_bool())? add_ln415_10_fu_1854_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_15_fu_6973_p3() {
    select_ln340_15_fu_6973_p3 = (!select_ln777_11_fu_1994_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_11_fu_1994_p3.read()[0].to_bool())? add_ln415_11_fu_1946_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_16_fu_6990_p3() {
    select_ln340_16_fu_6990_p3 = (!select_ln777_12_fu_2086_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_12_fu_2086_p3.read()[0].to_bool())? add_ln415_12_fu_2038_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_17_fu_7007_p3() {
    select_ln340_17_fu_7007_p3 = (!select_ln777_13_fu_2178_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_13_fu_2178_p3.read()[0].to_bool())? add_ln415_13_fu_2130_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_18_fu_7024_p3() {
    select_ln340_18_fu_7024_p3 = (!select_ln777_14_fu_2270_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_14_fu_2270_p3.read()[0].to_bool())? add_ln415_14_fu_2222_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_19_fu_7041_p3() {
    select_ln340_19_fu_7041_p3 = (!select_ln777_15_fu_2362_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_15_fu_2362_p3.read()[0].to_bool())? add_ln415_15_fu_2314_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_20_fu_7058_p3() {
    select_ln340_20_fu_7058_p3 = (!select_ln777_16_fu_2454_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_16_fu_2454_p3.read()[0].to_bool())? add_ln415_16_fu_2406_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_21_fu_7075_p3() {
    select_ln340_21_fu_7075_p3 = (!select_ln777_17_fu_2546_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_17_fu_2546_p3.read()[0].to_bool())? add_ln415_17_fu_2498_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_22_fu_7092_p3() {
    select_ln340_22_fu_7092_p3 = (!select_ln777_18_fu_2638_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_18_fu_2638_p3.read()[0].to_bool())? add_ln415_18_fu_2590_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_23_fu_7109_p3() {
    select_ln340_23_fu_7109_p3 = (!select_ln777_19_fu_2730_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_19_fu_2730_p3.read()[0].to_bool())? add_ln415_19_fu_2682_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_24_fu_7126_p3() {
    select_ln340_24_fu_7126_p3 = (!select_ln777_20_fu_2822_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_20_fu_2822_p3.read()[0].to_bool())? add_ln415_20_fu_2774_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_25_fu_7143_p3() {
    select_ln340_25_fu_7143_p3 = (!select_ln777_21_fu_2914_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_21_fu_2914_p3.read()[0].to_bool())? add_ln415_21_fu_2866_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_26_fu_7160_p3() {
    select_ln340_26_fu_7160_p3 = (!select_ln777_22_fu_3006_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_22_fu_3006_p3.read()[0].to_bool())? add_ln415_22_fu_2958_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_27_fu_7177_p3() {
    select_ln340_27_fu_7177_p3 = (!select_ln777_23_fu_3098_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_23_fu_3098_p3.read()[0].to_bool())? add_ln415_23_fu_3050_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_28_fu_7194_p3() {
    select_ln340_28_fu_7194_p3 = (!select_ln777_24_fu_3190_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_24_fu_3190_p3.read()[0].to_bool())? add_ln415_24_fu_3142_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_29_fu_7211_p3() {
    select_ln340_29_fu_7211_p3 = (!select_ln777_25_fu_3282_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_25_fu_3282_p3.read()[0].to_bool())? add_ln415_25_fu_3234_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_30_fu_7228_p3() {
    select_ln340_30_fu_7228_p3 = (!select_ln777_26_fu_3374_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_26_fu_3374_p3.read()[0].to_bool())? add_ln415_26_fu_3326_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_31_fu_7245_p3() {
    select_ln340_31_fu_7245_p3 = (!select_ln777_27_fu_3466_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_27_fu_3466_p3.read()[0].to_bool())? add_ln415_27_fu_3418_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_32_fu_7262_p3() {
    select_ln340_32_fu_7262_p3 = (!select_ln777_28_fu_3558_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_28_fu_3558_p3.read()[0].to_bool())? add_ln415_28_fu_3510_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_33_fu_7279_p3() {
    select_ln340_33_fu_7279_p3 = (!select_ln777_29_fu_3650_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_29_fu_3650_p3.read()[0].to_bool())? add_ln415_29_fu_3602_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_34_fu_7296_p3() {
    select_ln340_34_fu_7296_p3 = (!select_ln777_30_fu_3742_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_30_fu_3742_p3.read()[0].to_bool())? add_ln415_30_fu_3694_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_35_fu_7313_p3() {
    select_ln340_35_fu_7313_p3 = (!select_ln777_31_fu_3834_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_31_fu_3834_p3.read()[0].to_bool())? add_ln415_31_fu_3786_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_36_fu_7330_p3() {
    select_ln340_36_fu_7330_p3 = (!select_ln777_32_fu_3926_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_32_fu_3926_p3.read()[0].to_bool())? add_ln415_32_fu_3878_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_37_fu_7347_p3() {
    select_ln340_37_fu_7347_p3 = (!select_ln777_33_fu_4018_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_33_fu_4018_p3.read()[0].to_bool())? add_ln415_33_fu_3970_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_38_fu_7364_p3() {
    select_ln340_38_fu_7364_p3 = (!select_ln777_34_fu_4110_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_34_fu_4110_p3.read()[0].to_bool())? add_ln415_34_fu_4062_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_39_fu_7381_p3() {
    select_ln340_39_fu_7381_p3 = (!select_ln777_35_fu_4202_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_35_fu_4202_p3.read()[0].to_bool())? add_ln415_35_fu_4154_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_40_fu_7398_p3() {
    select_ln340_40_fu_7398_p3 = (!select_ln777_36_fu_4294_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_36_fu_4294_p3.read()[0].to_bool())? add_ln415_36_fu_4246_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_41_fu_7415_p3() {
    select_ln340_41_fu_7415_p3 = (!select_ln777_37_fu_4386_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_37_fu_4386_p3.read()[0].to_bool())? add_ln415_37_fu_4338_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_42_fu_7432_p3() {
    select_ln340_42_fu_7432_p3 = (!select_ln777_38_fu_4478_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_38_fu_4478_p3.read()[0].to_bool())? add_ln415_38_fu_4430_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_43_fu_7449_p3() {
    select_ln340_43_fu_7449_p3 = (!select_ln777_39_fu_4570_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_39_fu_4570_p3.read()[0].to_bool())? add_ln415_39_fu_4522_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_44_fu_7466_p3() {
    select_ln340_44_fu_7466_p3 = (!select_ln777_40_fu_4662_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_40_fu_4662_p3.read()[0].to_bool())? add_ln415_40_fu_4614_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_45_fu_7483_p3() {
    select_ln340_45_fu_7483_p3 = (!select_ln777_41_fu_4754_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_41_fu_4754_p3.read()[0].to_bool())? add_ln415_41_fu_4706_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_46_fu_7500_p3() {
    select_ln340_46_fu_7500_p3 = (!select_ln777_42_fu_4846_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_42_fu_4846_p3.read()[0].to_bool())? add_ln415_42_fu_4798_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_47_fu_7517_p3() {
    select_ln340_47_fu_7517_p3 = (!select_ln777_43_fu_4938_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_43_fu_4938_p3.read()[0].to_bool())? add_ln415_43_fu_4890_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_48_fu_7534_p3() {
    select_ln340_48_fu_7534_p3 = (!select_ln777_44_fu_5030_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_44_fu_5030_p3.read()[0].to_bool())? add_ln415_44_fu_4982_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_49_fu_7551_p3() {
    select_ln340_49_fu_7551_p3 = (!select_ln777_45_fu_5122_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_45_fu_5122_p3.read()[0].to_bool())? add_ln415_45_fu_5074_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_50_fu_7568_p3() {
    select_ln340_50_fu_7568_p3 = (!select_ln777_46_fu_5214_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_46_fu_5214_p3.read()[0].to_bool())? add_ln415_46_fu_5166_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_51_fu_7585_p3() {
    select_ln340_51_fu_7585_p3 = (!select_ln777_47_fu_5306_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_47_fu_5306_p3.read()[0].to_bool())? add_ln415_47_fu_5258_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_52_fu_7602_p3() {
    select_ln340_52_fu_7602_p3 = (!select_ln777_48_fu_5398_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_48_fu_5398_p3.read()[0].to_bool())? add_ln415_48_fu_5350_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_53_fu_7619_p3() {
    select_ln340_53_fu_7619_p3 = (!select_ln777_49_fu_5490_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_49_fu_5490_p3.read()[0].to_bool())? add_ln415_49_fu_5442_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_54_fu_7636_p3() {
    select_ln340_54_fu_7636_p3 = (!select_ln777_50_fu_5582_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_50_fu_5582_p3.read()[0].to_bool())? add_ln415_50_fu_5534_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_55_fu_7653_p3() {
    select_ln340_55_fu_7653_p3 = (!select_ln777_51_fu_5674_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_51_fu_5674_p3.read()[0].to_bool())? add_ln415_51_fu_5626_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_56_fu_7670_p3() {
    select_ln340_56_fu_7670_p3 = (!select_ln777_52_fu_5766_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_52_fu_5766_p3.read()[0].to_bool())? add_ln415_52_fu_5718_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_57_fu_7687_p3() {
    select_ln340_57_fu_7687_p3 = (!select_ln777_53_fu_5858_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_53_fu_5858_p3.read()[0].to_bool())? add_ln415_53_fu_5810_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_58_fu_7704_p3() {
    select_ln340_58_fu_7704_p3 = (!select_ln777_54_fu_5950_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_54_fu_5950_p3.read()[0].to_bool())? add_ln415_54_fu_5902_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_59_fu_7721_p3() {
    select_ln340_59_fu_7721_p3 = (!select_ln777_55_fu_6042_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_55_fu_6042_p3.read()[0].to_bool())? add_ln415_55_fu_5994_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_5_fu_6803_p3() {
    select_ln340_5_fu_6803_p3 = (!select_ln777_1_fu_1074_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_1_fu_1074_p3.read()[0].to_bool())? add_ln415_1_fu_1026_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_60_fu_7738_p3() {
    select_ln340_60_fu_7738_p3 = (!select_ln777_56_fu_6134_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_56_fu_6134_p3.read()[0].to_bool())? add_ln415_56_fu_6086_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_61_fu_7755_p3() {
    select_ln340_61_fu_7755_p3 = (!select_ln777_57_fu_6226_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_57_fu_6226_p3.read()[0].to_bool())? add_ln415_57_fu_6178_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_62_fu_7772_p3() {
    select_ln340_62_fu_7772_p3 = (!select_ln777_58_fu_6318_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_58_fu_6318_p3.read()[0].to_bool())? add_ln415_58_fu_6270_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_63_fu_7789_p3() {
    select_ln340_63_fu_7789_p3 = (!select_ln777_59_fu_6410_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_59_fu_6410_p3.read()[0].to_bool())? add_ln415_59_fu_6362_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_64_fu_7806_p3() {
    select_ln340_64_fu_7806_p3 = (!select_ln777_60_fu_6502_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_60_fu_6502_p3.read()[0].to_bool())? add_ln415_60_fu_6454_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_65_fu_7823_p3() {
    select_ln340_65_fu_7823_p3 = (!select_ln777_61_fu_6594_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_61_fu_6594_p3.read()[0].to_bool())? add_ln415_61_fu_6546_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_66_fu_7840_p3() {
    select_ln340_66_fu_7840_p3 = (!select_ln777_62_fu_6686_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_62_fu_6686_p3.read()[0].to_bool())? add_ln415_62_fu_6638_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_67_fu_7857_p3() {
    select_ln340_67_fu_7857_p3 = (!select_ln777_63_fu_6778_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_63_fu_6778_p3.read()[0].to_bool())? add_ln415_63_fu_6730_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_6_fu_6820_p3() {
    select_ln340_6_fu_6820_p3 = (!select_ln777_2_fu_1166_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_2_fu_1166_p3.read()[0].to_bool())? add_ln415_2_fu_1118_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_7_fu_6837_p3() {
    select_ln340_7_fu_6837_p3 = (!select_ln777_3_fu_1258_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_3_fu_1258_p3.read()[0].to_bool())? add_ln415_3_fu_1210_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_8_fu_6854_p3() {
    select_ln340_8_fu_6854_p3 = (!select_ln777_4_fu_1350_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_4_fu_1350_p3.read()[0].to_bool())? add_ln415_4_fu_1302_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_9_fu_6871_p3() {
    select_ln340_9_fu_6871_p3 = (!select_ln777_5_fu_1442_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_5_fu_1442_p3.read()[0].to_bool())? add_ln415_5_fu_1394_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln340_fu_6786_p3() {
    select_ln340_fu_6786_p3 = (!select_ln777_fu_982_p3.read()[0].is_01())? sc_lv<6>(): ((select_ln777_fu_982_p3.read()[0].to_bool())? add_ln415_fu_934_p2.read(): ap_const_lv6_3F);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_10_fu_1902_p3() {
    select_ln777_10_fu_1902_p3 = (!and_ln416_10_fu_1874_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_10_fu_1874_p2.read()[0].to_bool())? icmp_ln879_10_fu_1890_p2.read(): icmp_ln768_10_fu_1896_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_11_fu_1994_p3() {
    select_ln777_11_fu_1994_p3 = (!and_ln416_11_fu_1966_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_11_fu_1966_p2.read()[0].to_bool())? icmp_ln879_11_fu_1982_p2.read(): icmp_ln768_11_fu_1988_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_12_fu_2086_p3() {
    select_ln777_12_fu_2086_p3 = (!and_ln416_12_fu_2058_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_12_fu_2058_p2.read()[0].to_bool())? icmp_ln879_12_fu_2074_p2.read(): icmp_ln768_12_fu_2080_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_13_fu_2178_p3() {
    select_ln777_13_fu_2178_p3 = (!and_ln416_13_fu_2150_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_13_fu_2150_p2.read()[0].to_bool())? icmp_ln879_13_fu_2166_p2.read(): icmp_ln768_13_fu_2172_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_14_fu_2270_p3() {
    select_ln777_14_fu_2270_p3 = (!and_ln416_14_fu_2242_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_14_fu_2242_p2.read()[0].to_bool())? icmp_ln879_14_fu_2258_p2.read(): icmp_ln768_14_fu_2264_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_15_fu_2362_p3() {
    select_ln777_15_fu_2362_p3 = (!and_ln416_15_fu_2334_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_15_fu_2334_p2.read()[0].to_bool())? icmp_ln879_15_fu_2350_p2.read(): icmp_ln768_15_fu_2356_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_16_fu_2454_p3() {
    select_ln777_16_fu_2454_p3 = (!and_ln416_16_fu_2426_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_16_fu_2426_p2.read()[0].to_bool())? icmp_ln879_16_fu_2442_p2.read(): icmp_ln768_16_fu_2448_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_17_fu_2546_p3() {
    select_ln777_17_fu_2546_p3 = (!and_ln416_17_fu_2518_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_17_fu_2518_p2.read()[0].to_bool())? icmp_ln879_17_fu_2534_p2.read(): icmp_ln768_17_fu_2540_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_18_fu_2638_p3() {
    select_ln777_18_fu_2638_p3 = (!and_ln416_18_fu_2610_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_18_fu_2610_p2.read()[0].to_bool())? icmp_ln879_18_fu_2626_p2.read(): icmp_ln768_18_fu_2632_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_19_fu_2730_p3() {
    select_ln777_19_fu_2730_p3 = (!and_ln416_19_fu_2702_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_19_fu_2702_p2.read()[0].to_bool())? icmp_ln879_19_fu_2718_p2.read(): icmp_ln768_19_fu_2724_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_1_fu_1074_p3() {
    select_ln777_1_fu_1074_p3 = (!and_ln416_1_fu_1046_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_1_fu_1046_p2.read()[0].to_bool())? icmp_ln879_1_fu_1062_p2.read(): icmp_ln768_1_fu_1068_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_20_fu_2822_p3() {
    select_ln777_20_fu_2822_p3 = (!and_ln416_20_fu_2794_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_20_fu_2794_p2.read()[0].to_bool())? icmp_ln879_20_fu_2810_p2.read(): icmp_ln768_20_fu_2816_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_21_fu_2914_p3() {
    select_ln777_21_fu_2914_p3 = (!and_ln416_21_fu_2886_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_21_fu_2886_p2.read()[0].to_bool())? icmp_ln879_21_fu_2902_p2.read(): icmp_ln768_21_fu_2908_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_22_fu_3006_p3() {
    select_ln777_22_fu_3006_p3 = (!and_ln416_22_fu_2978_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_22_fu_2978_p2.read()[0].to_bool())? icmp_ln879_22_fu_2994_p2.read(): icmp_ln768_22_fu_3000_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_23_fu_3098_p3() {
    select_ln777_23_fu_3098_p3 = (!and_ln416_23_fu_3070_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_23_fu_3070_p2.read()[0].to_bool())? icmp_ln879_23_fu_3086_p2.read(): icmp_ln768_23_fu_3092_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_24_fu_3190_p3() {
    select_ln777_24_fu_3190_p3 = (!and_ln416_24_fu_3162_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_24_fu_3162_p2.read()[0].to_bool())? icmp_ln879_24_fu_3178_p2.read(): icmp_ln768_24_fu_3184_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_25_fu_3282_p3() {
    select_ln777_25_fu_3282_p3 = (!and_ln416_25_fu_3254_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_25_fu_3254_p2.read()[0].to_bool())? icmp_ln879_25_fu_3270_p2.read(): icmp_ln768_25_fu_3276_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_26_fu_3374_p3() {
    select_ln777_26_fu_3374_p3 = (!and_ln416_26_fu_3346_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_26_fu_3346_p2.read()[0].to_bool())? icmp_ln879_26_fu_3362_p2.read(): icmp_ln768_26_fu_3368_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_27_fu_3466_p3() {
    select_ln777_27_fu_3466_p3 = (!and_ln416_27_fu_3438_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_27_fu_3438_p2.read()[0].to_bool())? icmp_ln879_27_fu_3454_p2.read(): icmp_ln768_27_fu_3460_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_28_fu_3558_p3() {
    select_ln777_28_fu_3558_p3 = (!and_ln416_28_fu_3530_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_28_fu_3530_p2.read()[0].to_bool())? icmp_ln879_28_fu_3546_p2.read(): icmp_ln768_28_fu_3552_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_29_fu_3650_p3() {
    select_ln777_29_fu_3650_p3 = (!and_ln416_29_fu_3622_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_29_fu_3622_p2.read()[0].to_bool())? icmp_ln879_29_fu_3638_p2.read(): icmp_ln768_29_fu_3644_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_2_fu_1166_p3() {
    select_ln777_2_fu_1166_p3 = (!and_ln416_2_fu_1138_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_2_fu_1138_p2.read()[0].to_bool())? icmp_ln879_2_fu_1154_p2.read(): icmp_ln768_2_fu_1160_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_30_fu_3742_p3() {
    select_ln777_30_fu_3742_p3 = (!and_ln416_30_fu_3714_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_30_fu_3714_p2.read()[0].to_bool())? icmp_ln879_30_fu_3730_p2.read(): icmp_ln768_30_fu_3736_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_31_fu_3834_p3() {
    select_ln777_31_fu_3834_p3 = (!and_ln416_31_fu_3806_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_31_fu_3806_p2.read()[0].to_bool())? icmp_ln879_31_fu_3822_p2.read(): icmp_ln768_31_fu_3828_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_32_fu_3926_p3() {
    select_ln777_32_fu_3926_p3 = (!and_ln416_32_fu_3898_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_32_fu_3898_p2.read()[0].to_bool())? icmp_ln879_32_fu_3914_p2.read(): icmp_ln768_32_fu_3920_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_33_fu_4018_p3() {
    select_ln777_33_fu_4018_p3 = (!and_ln416_33_fu_3990_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_33_fu_3990_p2.read()[0].to_bool())? icmp_ln879_33_fu_4006_p2.read(): icmp_ln768_33_fu_4012_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_34_fu_4110_p3() {
    select_ln777_34_fu_4110_p3 = (!and_ln416_34_fu_4082_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_34_fu_4082_p2.read()[0].to_bool())? icmp_ln879_34_fu_4098_p2.read(): icmp_ln768_34_fu_4104_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_35_fu_4202_p3() {
    select_ln777_35_fu_4202_p3 = (!and_ln416_35_fu_4174_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_35_fu_4174_p2.read()[0].to_bool())? icmp_ln879_35_fu_4190_p2.read(): icmp_ln768_35_fu_4196_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_36_fu_4294_p3() {
    select_ln777_36_fu_4294_p3 = (!and_ln416_36_fu_4266_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_36_fu_4266_p2.read()[0].to_bool())? icmp_ln879_36_fu_4282_p2.read(): icmp_ln768_36_fu_4288_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_37_fu_4386_p3() {
    select_ln777_37_fu_4386_p3 = (!and_ln416_37_fu_4358_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_37_fu_4358_p2.read()[0].to_bool())? icmp_ln879_37_fu_4374_p2.read(): icmp_ln768_37_fu_4380_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_38_fu_4478_p3() {
    select_ln777_38_fu_4478_p3 = (!and_ln416_38_fu_4450_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_38_fu_4450_p2.read()[0].to_bool())? icmp_ln879_38_fu_4466_p2.read(): icmp_ln768_38_fu_4472_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_39_fu_4570_p3() {
    select_ln777_39_fu_4570_p3 = (!and_ln416_39_fu_4542_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_39_fu_4542_p2.read()[0].to_bool())? icmp_ln879_39_fu_4558_p2.read(): icmp_ln768_39_fu_4564_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_3_fu_1258_p3() {
    select_ln777_3_fu_1258_p3 = (!and_ln416_3_fu_1230_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_3_fu_1230_p2.read()[0].to_bool())? icmp_ln879_3_fu_1246_p2.read(): icmp_ln768_3_fu_1252_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_40_fu_4662_p3() {
    select_ln777_40_fu_4662_p3 = (!and_ln416_40_fu_4634_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_40_fu_4634_p2.read()[0].to_bool())? icmp_ln879_40_fu_4650_p2.read(): icmp_ln768_40_fu_4656_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_41_fu_4754_p3() {
    select_ln777_41_fu_4754_p3 = (!and_ln416_41_fu_4726_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_41_fu_4726_p2.read()[0].to_bool())? icmp_ln879_41_fu_4742_p2.read(): icmp_ln768_41_fu_4748_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_42_fu_4846_p3() {
    select_ln777_42_fu_4846_p3 = (!and_ln416_42_fu_4818_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_42_fu_4818_p2.read()[0].to_bool())? icmp_ln879_42_fu_4834_p2.read(): icmp_ln768_42_fu_4840_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_43_fu_4938_p3() {
    select_ln777_43_fu_4938_p3 = (!and_ln416_43_fu_4910_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_43_fu_4910_p2.read()[0].to_bool())? icmp_ln879_43_fu_4926_p2.read(): icmp_ln768_43_fu_4932_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_44_fu_5030_p3() {
    select_ln777_44_fu_5030_p3 = (!and_ln416_44_fu_5002_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_44_fu_5002_p2.read()[0].to_bool())? icmp_ln879_44_fu_5018_p2.read(): icmp_ln768_44_fu_5024_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_45_fu_5122_p3() {
    select_ln777_45_fu_5122_p3 = (!and_ln416_45_fu_5094_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_45_fu_5094_p2.read()[0].to_bool())? icmp_ln879_45_fu_5110_p2.read(): icmp_ln768_45_fu_5116_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_46_fu_5214_p3() {
    select_ln777_46_fu_5214_p3 = (!and_ln416_46_fu_5186_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_46_fu_5186_p2.read()[0].to_bool())? icmp_ln879_46_fu_5202_p2.read(): icmp_ln768_46_fu_5208_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_47_fu_5306_p3() {
    select_ln777_47_fu_5306_p3 = (!and_ln416_47_fu_5278_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_47_fu_5278_p2.read()[0].to_bool())? icmp_ln879_47_fu_5294_p2.read(): icmp_ln768_47_fu_5300_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_48_fu_5398_p3() {
    select_ln777_48_fu_5398_p3 = (!and_ln416_48_fu_5370_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_48_fu_5370_p2.read()[0].to_bool())? icmp_ln879_48_fu_5386_p2.read(): icmp_ln768_48_fu_5392_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_49_fu_5490_p3() {
    select_ln777_49_fu_5490_p3 = (!and_ln416_49_fu_5462_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_49_fu_5462_p2.read()[0].to_bool())? icmp_ln879_49_fu_5478_p2.read(): icmp_ln768_49_fu_5484_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_4_fu_1350_p3() {
    select_ln777_4_fu_1350_p3 = (!and_ln416_4_fu_1322_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_4_fu_1322_p2.read()[0].to_bool())? icmp_ln879_4_fu_1338_p2.read(): icmp_ln768_4_fu_1344_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_50_fu_5582_p3() {
    select_ln777_50_fu_5582_p3 = (!and_ln416_50_fu_5554_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_50_fu_5554_p2.read()[0].to_bool())? icmp_ln879_50_fu_5570_p2.read(): icmp_ln768_50_fu_5576_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_51_fu_5674_p3() {
    select_ln777_51_fu_5674_p3 = (!and_ln416_51_fu_5646_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_51_fu_5646_p2.read()[0].to_bool())? icmp_ln879_51_fu_5662_p2.read(): icmp_ln768_51_fu_5668_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_52_fu_5766_p3() {
    select_ln777_52_fu_5766_p3 = (!and_ln416_52_fu_5738_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_52_fu_5738_p2.read()[0].to_bool())? icmp_ln879_52_fu_5754_p2.read(): icmp_ln768_52_fu_5760_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_53_fu_5858_p3() {
    select_ln777_53_fu_5858_p3 = (!and_ln416_53_fu_5830_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_53_fu_5830_p2.read()[0].to_bool())? icmp_ln879_53_fu_5846_p2.read(): icmp_ln768_53_fu_5852_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_54_fu_5950_p3() {
    select_ln777_54_fu_5950_p3 = (!and_ln416_54_fu_5922_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_54_fu_5922_p2.read()[0].to_bool())? icmp_ln879_54_fu_5938_p2.read(): icmp_ln768_54_fu_5944_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_55_fu_6042_p3() {
    select_ln777_55_fu_6042_p3 = (!and_ln416_55_fu_6014_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_55_fu_6014_p2.read()[0].to_bool())? icmp_ln879_55_fu_6030_p2.read(): icmp_ln768_55_fu_6036_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_56_fu_6134_p3() {
    select_ln777_56_fu_6134_p3 = (!and_ln416_56_fu_6106_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_56_fu_6106_p2.read()[0].to_bool())? icmp_ln879_56_fu_6122_p2.read(): icmp_ln768_56_fu_6128_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_57_fu_6226_p3() {
    select_ln777_57_fu_6226_p3 = (!and_ln416_57_fu_6198_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_57_fu_6198_p2.read()[0].to_bool())? icmp_ln879_57_fu_6214_p2.read(): icmp_ln768_57_fu_6220_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_58_fu_6318_p3() {
    select_ln777_58_fu_6318_p3 = (!and_ln416_58_fu_6290_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_58_fu_6290_p2.read()[0].to_bool())? icmp_ln879_58_fu_6306_p2.read(): icmp_ln768_58_fu_6312_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_59_fu_6410_p3() {
    select_ln777_59_fu_6410_p3 = (!and_ln416_59_fu_6382_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_59_fu_6382_p2.read()[0].to_bool())? icmp_ln879_59_fu_6398_p2.read(): icmp_ln768_59_fu_6404_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_5_fu_1442_p3() {
    select_ln777_5_fu_1442_p3 = (!and_ln416_5_fu_1414_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_5_fu_1414_p2.read()[0].to_bool())? icmp_ln879_5_fu_1430_p2.read(): icmp_ln768_5_fu_1436_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_60_fu_6502_p3() {
    select_ln777_60_fu_6502_p3 = (!and_ln416_60_fu_6474_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_60_fu_6474_p2.read()[0].to_bool())? icmp_ln879_60_fu_6490_p2.read(): icmp_ln768_60_fu_6496_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_61_fu_6594_p3() {
    select_ln777_61_fu_6594_p3 = (!and_ln416_61_fu_6566_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_61_fu_6566_p2.read()[0].to_bool())? icmp_ln879_61_fu_6582_p2.read(): icmp_ln768_61_fu_6588_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_62_fu_6686_p3() {
    select_ln777_62_fu_6686_p3 = (!and_ln416_62_fu_6658_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_62_fu_6658_p2.read()[0].to_bool())? icmp_ln879_62_fu_6674_p2.read(): icmp_ln768_62_fu_6680_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_63_fu_6778_p3() {
    select_ln777_63_fu_6778_p3 = (!and_ln416_63_fu_6750_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_63_fu_6750_p2.read()[0].to_bool())? icmp_ln879_63_fu_6766_p2.read(): icmp_ln768_63_fu_6772_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_6_fu_1534_p3() {
    select_ln777_6_fu_1534_p3 = (!and_ln416_6_fu_1506_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_6_fu_1506_p2.read()[0].to_bool())? icmp_ln879_6_fu_1522_p2.read(): icmp_ln768_6_fu_1528_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_7_fu_1626_p3() {
    select_ln777_7_fu_1626_p3 = (!and_ln416_7_fu_1598_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_7_fu_1598_p2.read()[0].to_bool())? icmp_ln879_7_fu_1614_p2.read(): icmp_ln768_7_fu_1620_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_8_fu_1718_p3() {
    select_ln777_8_fu_1718_p3 = (!and_ln416_8_fu_1690_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_8_fu_1690_p2.read()[0].to_bool())? icmp_ln879_8_fu_1706_p2.read(): icmp_ln768_8_fu_1712_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_9_fu_1810_p3() {
    select_ln777_9_fu_1810_p3 = (!and_ln416_9_fu_1782_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_9_fu_1782_p2.read()[0].to_bool())? icmp_ln879_9_fu_1798_p2.read(): icmp_ln768_9_fu_1804_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_select_ln777_fu_982_p3() {
    select_ln777_fu_982_p3 = (!and_ln416_fu_954_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_fu_954_p2.read()[0].to_bool())? icmp_ln879_fu_970_p2.read(): icmp_ln768_fu_976_p2.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_start_out() {
    start_out = real_start.read();
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_start_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()))) {
        start_write = ap_const_logic_1;
    } else {
        start_write = ap_const_logic_0;
    }
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_100_fu_3582_p3() {
    tmp_100_fu_3582_p3 = data_V_data_29_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_101_fu_3590_p3() {
    tmp_101_fu_3590_p3 = data_V_data_29_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_102_fu_3608_p3() {
    tmp_102_fu_3608_p3 = add_ln415_29_fu_3602_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_103_fu_3674_p3() {
    tmp_103_fu_3674_p3 = data_V_data_30_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_104_fu_3682_p3() {
    tmp_104_fu_3682_p3 = data_V_data_30_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_105_fu_3700_p3() {
    tmp_105_fu_3700_p3 = add_ln415_30_fu_3694_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_106_fu_3766_p3() {
    tmp_106_fu_3766_p3 = data_V_data_31_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_107_fu_3774_p3() {
    tmp_107_fu_3774_p3 = data_V_data_31_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_108_fu_3792_p3() {
    tmp_108_fu_3792_p3 = add_ln415_31_fu_3786_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_109_fu_3858_p3() {
    tmp_109_fu_3858_p3 = data_V_data_32_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_110_fu_3866_p3() {
    tmp_110_fu_3866_p3 = data_V_data_32_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_111_fu_3884_p3() {
    tmp_111_fu_3884_p3 = add_ln415_32_fu_3878_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_112_fu_3950_p3() {
    tmp_112_fu_3950_p3 = data_V_data_33_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_113_fu_3958_p3() {
    tmp_113_fu_3958_p3 = data_V_data_33_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_114_fu_3976_p3() {
    tmp_114_fu_3976_p3 = add_ln415_33_fu_3970_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_115_fu_4042_p3() {
    tmp_115_fu_4042_p3 = data_V_data_34_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_116_fu_4050_p3() {
    tmp_116_fu_4050_p3 = data_V_data_34_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_117_fu_4068_p3() {
    tmp_117_fu_4068_p3 = add_ln415_34_fu_4062_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_118_fu_4134_p3() {
    tmp_118_fu_4134_p3 = data_V_data_35_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_119_fu_4142_p3() {
    tmp_119_fu_4142_p3 = data_V_data_35_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_120_fu_4160_p3() {
    tmp_120_fu_4160_p3 = add_ln415_35_fu_4154_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_121_fu_4226_p3() {
    tmp_121_fu_4226_p3 = data_V_data_36_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_122_fu_4234_p3() {
    tmp_122_fu_4234_p3 = data_V_data_36_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_123_fu_4252_p3() {
    tmp_123_fu_4252_p3 = add_ln415_36_fu_4246_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_124_fu_4318_p3() {
    tmp_124_fu_4318_p3 = data_V_data_37_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_125_fu_4326_p3() {
    tmp_125_fu_4326_p3 = data_V_data_37_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_126_fu_4344_p3() {
    tmp_126_fu_4344_p3 = add_ln415_37_fu_4338_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_127_fu_4410_p3() {
    tmp_127_fu_4410_p3 = data_V_data_38_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_128_fu_4418_p3() {
    tmp_128_fu_4418_p3 = data_V_data_38_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_129_fu_4436_p3() {
    tmp_129_fu_4436_p3 = add_ln415_38_fu_4430_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_130_fu_4502_p3() {
    tmp_130_fu_4502_p3 = data_V_data_39_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_131_fu_4510_p3() {
    tmp_131_fu_4510_p3 = data_V_data_39_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_132_fu_4528_p3() {
    tmp_132_fu_4528_p3 = add_ln415_39_fu_4522_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_133_fu_4594_p3() {
    tmp_133_fu_4594_p3 = data_V_data_40_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_134_fu_4602_p3() {
    tmp_134_fu_4602_p3 = data_V_data_40_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_135_fu_4620_p3() {
    tmp_135_fu_4620_p3 = add_ln415_40_fu_4614_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_136_fu_4686_p3() {
    tmp_136_fu_4686_p3 = data_V_data_41_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_137_fu_4694_p3() {
    tmp_137_fu_4694_p3 = data_V_data_41_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_138_fu_4712_p3() {
    tmp_138_fu_4712_p3 = add_ln415_41_fu_4706_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_139_fu_4778_p3() {
    tmp_139_fu_4778_p3 = data_V_data_42_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_13_fu_914_p3() {
    tmp_13_fu_914_p3 = data_V_data_0_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_140_fu_4786_p3() {
    tmp_140_fu_4786_p3 = data_V_data_42_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_141_fu_4804_p3() {
    tmp_141_fu_4804_p3 = add_ln415_42_fu_4798_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_142_fu_4870_p3() {
    tmp_142_fu_4870_p3 = data_V_data_43_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_143_fu_4878_p3() {
    tmp_143_fu_4878_p3 = data_V_data_43_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_144_fu_4896_p3() {
    tmp_144_fu_4896_p3 = add_ln415_43_fu_4890_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_145_fu_4962_p3() {
    tmp_145_fu_4962_p3 = data_V_data_44_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_146_fu_4970_p3() {
    tmp_146_fu_4970_p3 = data_V_data_44_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_147_fu_4988_p3() {
    tmp_147_fu_4988_p3 = add_ln415_44_fu_4982_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_148_fu_5054_p3() {
    tmp_148_fu_5054_p3 = data_V_data_45_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_149_fu_5062_p3() {
    tmp_149_fu_5062_p3 = data_V_data_45_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_14_fu_922_p3() {
    tmp_14_fu_922_p3 = data_V_data_0_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_150_fu_5080_p3() {
    tmp_150_fu_5080_p3 = add_ln415_45_fu_5074_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_151_fu_5146_p3() {
    tmp_151_fu_5146_p3 = data_V_data_46_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_152_fu_5154_p3() {
    tmp_152_fu_5154_p3 = data_V_data_46_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_153_fu_5172_p3() {
    tmp_153_fu_5172_p3 = add_ln415_46_fu_5166_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_154_fu_5238_p3() {
    tmp_154_fu_5238_p3 = data_V_data_47_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_155_fu_5246_p3() {
    tmp_155_fu_5246_p3 = data_V_data_47_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_156_fu_5264_p3() {
    tmp_156_fu_5264_p3 = add_ln415_47_fu_5258_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_157_fu_5330_p3() {
    tmp_157_fu_5330_p3 = data_V_data_48_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_158_fu_5338_p3() {
    tmp_158_fu_5338_p3 = data_V_data_48_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_159_fu_5356_p3() {
    tmp_159_fu_5356_p3 = add_ln415_48_fu_5350_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_15_fu_940_p3() {
    tmp_15_fu_940_p3 = add_ln415_fu_934_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_160_fu_5422_p3() {
    tmp_160_fu_5422_p3 = data_V_data_49_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_161_fu_5430_p3() {
    tmp_161_fu_5430_p3 = data_V_data_49_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_162_fu_5448_p3() {
    tmp_162_fu_5448_p3 = add_ln415_49_fu_5442_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_163_fu_5514_p3() {
    tmp_163_fu_5514_p3 = data_V_data_50_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_164_fu_5522_p3() {
    tmp_164_fu_5522_p3 = data_V_data_50_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_165_fu_5540_p3() {
    tmp_165_fu_5540_p3 = add_ln415_50_fu_5534_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_166_fu_5606_p3() {
    tmp_166_fu_5606_p3 = data_V_data_51_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_167_fu_5614_p3() {
    tmp_167_fu_5614_p3 = data_V_data_51_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_168_fu_5632_p3() {
    tmp_168_fu_5632_p3 = add_ln415_51_fu_5626_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_169_fu_5698_p3() {
    tmp_169_fu_5698_p3 = data_V_data_52_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_16_fu_1006_p3() {
    tmp_16_fu_1006_p3 = data_V_data_1_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_170_fu_5706_p3() {
    tmp_170_fu_5706_p3 = data_V_data_52_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_171_fu_5724_p3() {
    tmp_171_fu_5724_p3 = add_ln415_52_fu_5718_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_172_fu_5790_p3() {
    tmp_172_fu_5790_p3 = data_V_data_53_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_173_fu_5798_p3() {
    tmp_173_fu_5798_p3 = data_V_data_53_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_174_fu_5816_p3() {
    tmp_174_fu_5816_p3 = add_ln415_53_fu_5810_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_175_fu_5882_p3() {
    tmp_175_fu_5882_p3 = data_V_data_54_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_176_fu_5890_p3() {
    tmp_176_fu_5890_p3 = data_V_data_54_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_177_fu_5908_p3() {
    tmp_177_fu_5908_p3 = add_ln415_54_fu_5902_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_178_fu_5974_p3() {
    tmp_178_fu_5974_p3 = data_V_data_55_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_179_fu_5982_p3() {
    tmp_179_fu_5982_p3 = data_V_data_55_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_17_fu_1014_p3() {
    tmp_17_fu_1014_p3 = data_V_data_1_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_180_fu_6000_p3() {
    tmp_180_fu_6000_p3 = add_ln415_55_fu_5994_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_181_fu_6066_p3() {
    tmp_181_fu_6066_p3 = data_V_data_56_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_182_fu_6074_p3() {
    tmp_182_fu_6074_p3 = data_V_data_56_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_183_fu_6092_p3() {
    tmp_183_fu_6092_p3 = add_ln415_56_fu_6086_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_184_fu_6158_p3() {
    tmp_184_fu_6158_p3 = data_V_data_57_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_185_fu_6166_p3() {
    tmp_185_fu_6166_p3 = data_V_data_57_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_186_fu_6184_p3() {
    tmp_186_fu_6184_p3 = add_ln415_57_fu_6178_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_187_fu_6250_p3() {
    tmp_187_fu_6250_p3 = data_V_data_58_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_188_fu_6258_p3() {
    tmp_188_fu_6258_p3 = data_V_data_58_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_189_fu_6276_p3() {
    tmp_189_fu_6276_p3 = add_ln415_58_fu_6270_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_18_fu_1032_p3() {
    tmp_18_fu_1032_p3 = add_ln415_1_fu_1026_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_190_fu_6342_p3() {
    tmp_190_fu_6342_p3 = data_V_data_59_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_191_fu_6350_p3() {
    tmp_191_fu_6350_p3 = data_V_data_59_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_192_fu_6368_p3() {
    tmp_192_fu_6368_p3 = add_ln415_59_fu_6362_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_193_fu_6434_p3() {
    tmp_193_fu_6434_p3 = data_V_data_60_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_194_fu_6442_p3() {
    tmp_194_fu_6442_p3 = data_V_data_60_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_195_fu_6460_p3() {
    tmp_195_fu_6460_p3 = add_ln415_60_fu_6454_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_196_fu_6526_p3() {
    tmp_196_fu_6526_p3 = data_V_data_61_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_197_fu_6534_p3() {
    tmp_197_fu_6534_p3 = data_V_data_61_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_198_fu_6552_p3() {
    tmp_198_fu_6552_p3 = add_ln415_61_fu_6546_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_199_fu_6618_p3() {
    tmp_199_fu_6618_p3 = data_V_data_62_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_19_fu_1098_p3() {
    tmp_19_fu_1098_p3 = data_V_data_2_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_200_fu_6626_p3() {
    tmp_200_fu_6626_p3 = data_V_data_62_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_201_fu_6644_p3() {
    tmp_201_fu_6644_p3 = add_ln415_62_fu_6638_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_202_fu_6710_p3() {
    tmp_202_fu_6710_p3 = data_V_data_63_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_203_fu_6718_p3() {
    tmp_203_fu_6718_p3 = data_V_data_63_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_204_fu_6736_p3() {
    tmp_204_fu_6736_p3 = add_ln415_63_fu_6730_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_20_fu_1106_p3() {
    tmp_20_fu_1106_p3 = data_V_data_2_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_21_fu_1124_p3() {
    tmp_21_fu_1124_p3 = add_ln415_2_fu_1118_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_22_fu_1190_p3() {
    tmp_22_fu_1190_p3 = data_V_data_3_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_23_fu_1198_p3() {
    tmp_23_fu_1198_p3 = data_V_data_3_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_24_fu_1216_p3() {
    tmp_24_fu_1216_p3 = add_ln415_3_fu_1210_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_25_fu_1282_p3() {
    tmp_25_fu_1282_p3 = data_V_data_4_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_26_fu_1290_p3() {
    tmp_26_fu_1290_p3 = data_V_data_4_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_27_fu_1308_p3() {
    tmp_27_fu_1308_p3 = add_ln415_4_fu_1302_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_28_fu_1374_p3() {
    tmp_28_fu_1374_p3 = data_V_data_5_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_29_fu_1382_p3() {
    tmp_29_fu_1382_p3 = data_V_data_5_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_30_fu_1400_p3() {
    tmp_30_fu_1400_p3 = add_ln415_5_fu_1394_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_31_fu_1466_p3() {
    tmp_31_fu_1466_p3 = data_V_data_6_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_32_fu_1474_p3() {
    tmp_32_fu_1474_p3 = data_V_data_6_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_33_fu_1492_p3() {
    tmp_33_fu_1492_p3 = add_ln415_6_fu_1486_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_34_fu_1558_p3() {
    tmp_34_fu_1558_p3 = data_V_data_7_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_35_fu_1566_p3() {
    tmp_35_fu_1566_p3 = data_V_data_7_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_36_fu_1584_p3() {
    tmp_36_fu_1584_p3 = add_ln415_7_fu_1578_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_37_fu_1650_p3() {
    tmp_37_fu_1650_p3 = data_V_data_8_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_38_fu_1658_p3() {
    tmp_38_fu_1658_p3 = data_V_data_8_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_39_fu_1676_p3() {
    tmp_39_fu_1676_p3 = add_ln415_8_fu_1670_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_40_fu_1742_p3() {
    tmp_40_fu_1742_p3 = data_V_data_9_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_41_fu_1750_p3() {
    tmp_41_fu_1750_p3 = data_V_data_9_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_42_fu_1768_p3() {
    tmp_42_fu_1768_p3 = add_ln415_9_fu_1762_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_43_fu_1834_p3() {
    tmp_43_fu_1834_p3 = data_V_data_10_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_44_fu_1842_p3() {
    tmp_44_fu_1842_p3 = data_V_data_10_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_45_fu_1860_p3() {
    tmp_45_fu_1860_p3 = add_ln415_10_fu_1854_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_46_fu_1926_p3() {
    tmp_46_fu_1926_p3 = data_V_data_11_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_47_fu_1934_p3() {
    tmp_47_fu_1934_p3 = data_V_data_11_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_48_fu_1952_p3() {
    tmp_48_fu_1952_p3 = add_ln415_11_fu_1946_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_49_fu_2018_p3() {
    tmp_49_fu_2018_p3 = data_V_data_12_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_50_fu_2026_p3() {
    tmp_50_fu_2026_p3 = data_V_data_12_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_51_fu_2044_p3() {
    tmp_51_fu_2044_p3 = add_ln415_12_fu_2038_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_52_fu_2110_p3() {
    tmp_52_fu_2110_p3 = data_V_data_13_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_53_fu_2118_p3() {
    tmp_53_fu_2118_p3 = data_V_data_13_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_54_fu_2136_p3() {
    tmp_54_fu_2136_p3 = add_ln415_13_fu_2130_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_55_fu_2202_p3() {
    tmp_55_fu_2202_p3 = data_V_data_14_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_56_fu_2210_p3() {
    tmp_56_fu_2210_p3 = data_V_data_14_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_57_fu_2228_p3() {
    tmp_57_fu_2228_p3 = add_ln415_14_fu_2222_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_58_fu_2294_p3() {
    tmp_58_fu_2294_p3 = data_V_data_15_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_59_fu_2302_p3() {
    tmp_59_fu_2302_p3 = data_V_data_15_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_60_fu_2320_p3() {
    tmp_60_fu_2320_p3 = add_ln415_15_fu_2314_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_61_fu_2386_p3() {
    tmp_61_fu_2386_p3 = data_V_data_16_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_62_fu_2394_p3() {
    tmp_62_fu_2394_p3 = data_V_data_16_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_63_fu_2412_p3() {
    tmp_63_fu_2412_p3 = add_ln415_16_fu_2406_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_64_fu_2478_p3() {
    tmp_64_fu_2478_p3 = data_V_data_17_V_dout.read().range(9, 9);
}

}

