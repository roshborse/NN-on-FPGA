#include "relu_array_array_ap_ufixed_64u_relu_config4_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_65_fu_2486_p3() {
    tmp_65_fu_2486_p3 = data_V_data_17_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_66_fu_2504_p3() {
    tmp_66_fu_2504_p3 = add_ln415_17_fu_2498_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_67_fu_2570_p3() {
    tmp_67_fu_2570_p3 = data_V_data_18_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_68_fu_2578_p3() {
    tmp_68_fu_2578_p3 = data_V_data_18_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_69_fu_2596_p3() {
    tmp_69_fu_2596_p3 = add_ln415_18_fu_2590_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_70_fu_2662_p3() {
    tmp_70_fu_2662_p3 = data_V_data_19_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_71_fu_2670_p3() {
    tmp_71_fu_2670_p3 = data_V_data_19_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_72_fu_2688_p3() {
    tmp_72_fu_2688_p3 = add_ln415_19_fu_2682_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_73_fu_2754_p3() {
    tmp_73_fu_2754_p3 = data_V_data_20_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_74_fu_2762_p3() {
    tmp_74_fu_2762_p3 = data_V_data_20_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_75_fu_2780_p3() {
    tmp_75_fu_2780_p3 = add_ln415_20_fu_2774_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_76_fu_2846_p3() {
    tmp_76_fu_2846_p3 = data_V_data_21_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_77_fu_2854_p3() {
    tmp_77_fu_2854_p3 = data_V_data_21_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_78_fu_2872_p3() {
    tmp_78_fu_2872_p3 = add_ln415_21_fu_2866_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_79_fu_2938_p3() {
    tmp_79_fu_2938_p3 = data_V_data_22_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_80_fu_2946_p3() {
    tmp_80_fu_2946_p3 = data_V_data_22_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_81_fu_2964_p3() {
    tmp_81_fu_2964_p3 = add_ln415_22_fu_2958_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_82_fu_3030_p3() {
    tmp_82_fu_3030_p3 = data_V_data_23_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_83_fu_3038_p3() {
    tmp_83_fu_3038_p3 = data_V_data_23_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_84_fu_3056_p3() {
    tmp_84_fu_3056_p3 = add_ln415_23_fu_3050_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_85_fu_3122_p3() {
    tmp_85_fu_3122_p3 = data_V_data_24_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_86_fu_3130_p3() {
    tmp_86_fu_3130_p3 = data_V_data_24_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_87_fu_3148_p3() {
    tmp_87_fu_3148_p3 = add_ln415_24_fu_3142_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_88_fu_3214_p3() {
    tmp_88_fu_3214_p3 = data_V_data_25_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_89_fu_3222_p3() {
    tmp_89_fu_3222_p3 = data_V_data_25_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_90_fu_3240_p3() {
    tmp_90_fu_3240_p3 = add_ln415_25_fu_3234_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_91_fu_3306_p3() {
    tmp_91_fu_3306_p3 = data_V_data_26_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_92_fu_3314_p3() {
    tmp_92_fu_3314_p3 = data_V_data_26_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_93_fu_3332_p3() {
    tmp_93_fu_3332_p3 = add_ln415_26_fu_3326_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_94_fu_3398_p3() {
    tmp_94_fu_3398_p3 = data_V_data_27_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_95_fu_3406_p3() {
    tmp_95_fu_3406_p3 = data_V_data_27_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_96_fu_3424_p3() {
    tmp_96_fu_3424_p3 = add_ln415_27_fu_3418_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_97_fu_3490_p3() {
    tmp_97_fu_3490_p3 = data_V_data_28_V_dout.read().range(9, 9);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_98_fu_3498_p3() {
    tmp_98_fu_3498_p3 = data_V_data_28_V_dout.read().range(3, 3);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_tmp_99_fu_3516_p3() {
    tmp_99_fu_3516_p3 = add_ln415_28_fu_3510_p2.read().range(5, 5);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_10_fu_1916_p4() {
    trunc_ln708_10_fu_1916_p4 = data_V_data_11_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_11_fu_2008_p4() {
    trunc_ln708_11_fu_2008_p4 = data_V_data_12_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_12_fu_2100_p4() {
    trunc_ln708_12_fu_2100_p4 = data_V_data_13_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_13_fu_2192_p4() {
    trunc_ln708_13_fu_2192_p4 = data_V_data_14_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_14_fu_2284_p4() {
    trunc_ln708_14_fu_2284_p4 = data_V_data_15_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_15_fu_2376_p4() {
    trunc_ln708_15_fu_2376_p4 = data_V_data_16_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_16_fu_2468_p4() {
    trunc_ln708_16_fu_2468_p4 = data_V_data_17_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_17_fu_2560_p4() {
    trunc_ln708_17_fu_2560_p4 = data_V_data_18_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_18_fu_2652_p4() {
    trunc_ln708_18_fu_2652_p4 = data_V_data_19_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_19_fu_2744_p4() {
    trunc_ln708_19_fu_2744_p4 = data_V_data_20_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_1_fu_1548_p4() {
    trunc_ln708_1_fu_1548_p4 = data_V_data_7_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_20_fu_2836_p4() {
    trunc_ln708_20_fu_2836_p4 = data_V_data_21_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_21_fu_2928_p4() {
    trunc_ln708_21_fu_2928_p4 = data_V_data_22_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_22_fu_3020_p4() {
    trunc_ln708_22_fu_3020_p4 = data_V_data_23_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_23_fu_3112_p4() {
    trunc_ln708_23_fu_3112_p4 = data_V_data_24_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_24_fu_3204_p4() {
    trunc_ln708_24_fu_3204_p4 = data_V_data_25_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_25_fu_3296_p4() {
    trunc_ln708_25_fu_3296_p4 = data_V_data_26_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_26_fu_3388_p4() {
    trunc_ln708_26_fu_3388_p4 = data_V_data_27_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_27_fu_3480_p4() {
    trunc_ln708_27_fu_3480_p4 = data_V_data_28_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_28_fu_3572_p4() {
    trunc_ln708_28_fu_3572_p4 = data_V_data_29_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_29_fu_3664_p4() {
    trunc_ln708_29_fu_3664_p4 = data_V_data_30_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_2_fu_1640_p4() {
    trunc_ln708_2_fu_1640_p4 = data_V_data_8_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_30_fu_3756_p4() {
    trunc_ln708_30_fu_3756_p4 = data_V_data_31_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_31_fu_3848_p4() {
    trunc_ln708_31_fu_3848_p4 = data_V_data_32_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_32_fu_3940_p4() {
    trunc_ln708_32_fu_3940_p4 = data_V_data_33_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_33_fu_4032_p4() {
    trunc_ln708_33_fu_4032_p4 = data_V_data_34_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_34_fu_4124_p4() {
    trunc_ln708_34_fu_4124_p4 = data_V_data_35_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_35_fu_4216_p4() {
    trunc_ln708_35_fu_4216_p4 = data_V_data_36_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_36_fu_4308_p4() {
    trunc_ln708_36_fu_4308_p4 = data_V_data_37_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_37_fu_4400_p4() {
    trunc_ln708_37_fu_4400_p4 = data_V_data_38_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_38_fu_4492_p4() {
    trunc_ln708_38_fu_4492_p4 = data_V_data_39_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_39_fu_4584_p4() {
    trunc_ln708_39_fu_4584_p4 = data_V_data_40_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_3_fu_1732_p4() {
    trunc_ln708_3_fu_1732_p4 = data_V_data_9_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_40_fu_4676_p4() {
    trunc_ln708_40_fu_4676_p4 = data_V_data_41_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_41_fu_4768_p4() {
    trunc_ln708_41_fu_4768_p4 = data_V_data_42_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_42_fu_4860_p4() {
    trunc_ln708_42_fu_4860_p4 = data_V_data_43_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_43_fu_4952_p4() {
    trunc_ln708_43_fu_4952_p4 = data_V_data_44_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_44_fu_5044_p4() {
    trunc_ln708_44_fu_5044_p4 = data_V_data_45_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_45_fu_5136_p4() {
    trunc_ln708_45_fu_5136_p4 = data_V_data_46_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_46_fu_5228_p4() {
    trunc_ln708_46_fu_5228_p4 = data_V_data_47_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_47_fu_5320_p4() {
    trunc_ln708_47_fu_5320_p4 = data_V_data_48_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_48_fu_5412_p4() {
    trunc_ln708_48_fu_5412_p4 = data_V_data_49_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_49_fu_5504_p4() {
    trunc_ln708_49_fu_5504_p4 = data_V_data_50_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_4_fu_1824_p4() {
    trunc_ln708_4_fu_1824_p4 = data_V_data_10_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_50_fu_5596_p4() {
    trunc_ln708_50_fu_5596_p4 = data_V_data_51_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_51_fu_5688_p4() {
    trunc_ln708_51_fu_5688_p4 = data_V_data_52_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_52_fu_5780_p4() {
    trunc_ln708_52_fu_5780_p4 = data_V_data_53_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_53_fu_5872_p4() {
    trunc_ln708_53_fu_5872_p4 = data_V_data_54_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_54_fu_5964_p4() {
    trunc_ln708_54_fu_5964_p4 = data_V_data_55_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_55_fu_6056_p4() {
    trunc_ln708_55_fu_6056_p4 = data_V_data_56_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_56_fu_6148_p4() {
    trunc_ln708_56_fu_6148_p4 = data_V_data_57_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_57_fu_6240_p4() {
    trunc_ln708_57_fu_6240_p4 = data_V_data_58_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_58_fu_6332_p4() {
    trunc_ln708_58_fu_6332_p4 = data_V_data_59_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_59_fu_6424_p4() {
    trunc_ln708_59_fu_6424_p4 = data_V_data_60_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_5_fu_996_p4() {
    trunc_ln708_5_fu_996_p4 = data_V_data_1_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_60_fu_6516_p4() {
    trunc_ln708_60_fu_6516_p4 = data_V_data_61_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_61_fu_6608_p4() {
    trunc_ln708_61_fu_6608_p4 = data_V_data_62_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_62_fu_6700_p4() {
    trunc_ln708_62_fu_6700_p4 = data_V_data_63_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_6_fu_1088_p4() {
    trunc_ln708_6_fu_1088_p4 = data_V_data_2_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_7_fu_1180_p4() {
    trunc_ln708_7_fu_1180_p4 = data_V_data_3_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_8_fu_1272_p4() {
    trunc_ln708_8_fu_1272_p4 = data_V_data_4_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_9_fu_1364_p4() {
    trunc_ln708_9_fu_1364_p4 = data_V_data_5_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln708_s_fu_1456_p4() {
    trunc_ln708_s_fu_1456_p4 = data_V_data_6_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_trunc_ln_fu_904_p4() {
    trunc_ln_fu_904_p4 = data_V_data_0_V_dout.read().range(9, 4);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_10_fu_1868_p2() {
    xor_ln416_10_fu_1868_p2 = (tmp_45_fu_1860_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_11_fu_1960_p2() {
    xor_ln416_11_fu_1960_p2 = (tmp_48_fu_1952_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_12_fu_2052_p2() {
    xor_ln416_12_fu_2052_p2 = (tmp_51_fu_2044_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_13_fu_2144_p2() {
    xor_ln416_13_fu_2144_p2 = (tmp_54_fu_2136_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_14_fu_2236_p2() {
    xor_ln416_14_fu_2236_p2 = (tmp_57_fu_2228_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_15_fu_2328_p2() {
    xor_ln416_15_fu_2328_p2 = (tmp_60_fu_2320_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_16_fu_2420_p2() {
    xor_ln416_16_fu_2420_p2 = (tmp_63_fu_2412_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_17_fu_2512_p2() {
    xor_ln416_17_fu_2512_p2 = (tmp_66_fu_2504_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_18_fu_2604_p2() {
    xor_ln416_18_fu_2604_p2 = (tmp_69_fu_2596_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_19_fu_2696_p2() {
    xor_ln416_19_fu_2696_p2 = (tmp_72_fu_2688_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_1_fu_1040_p2() {
    xor_ln416_1_fu_1040_p2 = (tmp_18_fu_1032_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_20_fu_2788_p2() {
    xor_ln416_20_fu_2788_p2 = (tmp_75_fu_2780_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_21_fu_2880_p2() {
    xor_ln416_21_fu_2880_p2 = (tmp_78_fu_2872_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_22_fu_2972_p2() {
    xor_ln416_22_fu_2972_p2 = (tmp_81_fu_2964_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_23_fu_3064_p2() {
    xor_ln416_23_fu_3064_p2 = (tmp_84_fu_3056_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_24_fu_3156_p2() {
    xor_ln416_24_fu_3156_p2 = (tmp_87_fu_3148_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_25_fu_3248_p2() {
    xor_ln416_25_fu_3248_p2 = (tmp_90_fu_3240_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_26_fu_3340_p2() {
    xor_ln416_26_fu_3340_p2 = (tmp_93_fu_3332_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_27_fu_3432_p2() {
    xor_ln416_27_fu_3432_p2 = (tmp_96_fu_3424_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_28_fu_3524_p2() {
    xor_ln416_28_fu_3524_p2 = (tmp_99_fu_3516_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_29_fu_3616_p2() {
    xor_ln416_29_fu_3616_p2 = (tmp_102_fu_3608_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_2_fu_1132_p2() {
    xor_ln416_2_fu_1132_p2 = (tmp_21_fu_1124_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_30_fu_3708_p2() {
    xor_ln416_30_fu_3708_p2 = (tmp_105_fu_3700_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_31_fu_3800_p2() {
    xor_ln416_31_fu_3800_p2 = (tmp_108_fu_3792_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_32_fu_3892_p2() {
    xor_ln416_32_fu_3892_p2 = (tmp_111_fu_3884_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_33_fu_3984_p2() {
    xor_ln416_33_fu_3984_p2 = (tmp_114_fu_3976_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_34_fu_4076_p2() {
    xor_ln416_34_fu_4076_p2 = (tmp_117_fu_4068_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_35_fu_4168_p2() {
    xor_ln416_35_fu_4168_p2 = (tmp_120_fu_4160_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_36_fu_4260_p2() {
    xor_ln416_36_fu_4260_p2 = (tmp_123_fu_4252_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_37_fu_4352_p2() {
    xor_ln416_37_fu_4352_p2 = (tmp_126_fu_4344_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_38_fu_4444_p2() {
    xor_ln416_38_fu_4444_p2 = (tmp_129_fu_4436_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_39_fu_4536_p2() {
    xor_ln416_39_fu_4536_p2 = (tmp_132_fu_4528_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_3_fu_1224_p2() {
    xor_ln416_3_fu_1224_p2 = (tmp_24_fu_1216_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_40_fu_4628_p2() {
    xor_ln416_40_fu_4628_p2 = (tmp_135_fu_4620_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_41_fu_4720_p2() {
    xor_ln416_41_fu_4720_p2 = (tmp_138_fu_4712_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_42_fu_4812_p2() {
    xor_ln416_42_fu_4812_p2 = (tmp_141_fu_4804_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_43_fu_4904_p2() {
    xor_ln416_43_fu_4904_p2 = (tmp_144_fu_4896_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_44_fu_4996_p2() {
    xor_ln416_44_fu_4996_p2 = (tmp_147_fu_4988_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_45_fu_5088_p2() {
    xor_ln416_45_fu_5088_p2 = (tmp_150_fu_5080_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_46_fu_5180_p2() {
    xor_ln416_46_fu_5180_p2 = (tmp_153_fu_5172_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_47_fu_5272_p2() {
    xor_ln416_47_fu_5272_p2 = (tmp_156_fu_5264_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_48_fu_5364_p2() {
    xor_ln416_48_fu_5364_p2 = (tmp_159_fu_5356_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_49_fu_5456_p2() {
    xor_ln416_49_fu_5456_p2 = (tmp_162_fu_5448_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_4_fu_1316_p2() {
    xor_ln416_4_fu_1316_p2 = (tmp_27_fu_1308_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_50_fu_5548_p2() {
    xor_ln416_50_fu_5548_p2 = (tmp_165_fu_5540_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_51_fu_5640_p2() {
    xor_ln416_51_fu_5640_p2 = (tmp_168_fu_5632_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_52_fu_5732_p2() {
    xor_ln416_52_fu_5732_p2 = (tmp_171_fu_5724_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_53_fu_5824_p2() {
    xor_ln416_53_fu_5824_p2 = (tmp_174_fu_5816_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_54_fu_5916_p2() {
    xor_ln416_54_fu_5916_p2 = (tmp_177_fu_5908_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_55_fu_6008_p2() {
    xor_ln416_55_fu_6008_p2 = (tmp_180_fu_6000_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_56_fu_6100_p2() {
    xor_ln416_56_fu_6100_p2 = (tmp_183_fu_6092_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_57_fu_6192_p2() {
    xor_ln416_57_fu_6192_p2 = (tmp_186_fu_6184_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_58_fu_6284_p2() {
    xor_ln416_58_fu_6284_p2 = (tmp_189_fu_6276_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_59_fu_6376_p2() {
    xor_ln416_59_fu_6376_p2 = (tmp_192_fu_6368_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_5_fu_1408_p2() {
    xor_ln416_5_fu_1408_p2 = (tmp_30_fu_1400_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_60_fu_6468_p2() {
    xor_ln416_60_fu_6468_p2 = (tmp_195_fu_6460_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_61_fu_6560_p2() {
    xor_ln416_61_fu_6560_p2 = (tmp_198_fu_6552_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_62_fu_6652_p2() {
    xor_ln416_62_fu_6652_p2 = (tmp_201_fu_6644_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_63_fu_6744_p2() {
    xor_ln416_63_fu_6744_p2 = (tmp_204_fu_6736_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_6_fu_1500_p2() {
    xor_ln416_6_fu_1500_p2 = (tmp_33_fu_1492_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_7_fu_1592_p2() {
    xor_ln416_7_fu_1592_p2 = (tmp_36_fu_1584_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_8_fu_1684_p2() {
    xor_ln416_8_fu_1684_p2 = (tmp_39_fu_1676_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_9_fu_1776_p2() {
    xor_ln416_9_fu_1776_p2 = (tmp_42_fu_1768_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_xor_ln416_fu_948_p2() {
    xor_ln416_fu_948_p2 = (tmp_15_fu_940_p3.read() ^ ap_const_lv1_1);
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_10_fu_1850_p1() {
    zext_ln415_10_fu_1850_p1 = esl_zext<6,1>(tmp_44_fu_1842_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_11_fu_1942_p1() {
    zext_ln415_11_fu_1942_p1 = esl_zext<6,1>(tmp_47_fu_1934_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_12_fu_2034_p1() {
    zext_ln415_12_fu_2034_p1 = esl_zext<6,1>(tmp_50_fu_2026_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_13_fu_2126_p1() {
    zext_ln415_13_fu_2126_p1 = esl_zext<6,1>(tmp_53_fu_2118_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_14_fu_2218_p1() {
    zext_ln415_14_fu_2218_p1 = esl_zext<6,1>(tmp_56_fu_2210_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_15_fu_2310_p1() {
    zext_ln415_15_fu_2310_p1 = esl_zext<6,1>(tmp_59_fu_2302_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_16_fu_2402_p1() {
    zext_ln415_16_fu_2402_p1 = esl_zext<6,1>(tmp_62_fu_2394_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_17_fu_2494_p1() {
    zext_ln415_17_fu_2494_p1 = esl_zext<6,1>(tmp_65_fu_2486_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_18_fu_2586_p1() {
    zext_ln415_18_fu_2586_p1 = esl_zext<6,1>(tmp_68_fu_2578_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_19_fu_2678_p1() {
    zext_ln415_19_fu_2678_p1 = esl_zext<6,1>(tmp_71_fu_2670_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_1_fu_1022_p1() {
    zext_ln415_1_fu_1022_p1 = esl_zext<6,1>(tmp_17_fu_1014_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_20_fu_2770_p1() {
    zext_ln415_20_fu_2770_p1 = esl_zext<6,1>(tmp_74_fu_2762_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_21_fu_2862_p1() {
    zext_ln415_21_fu_2862_p1 = esl_zext<6,1>(tmp_77_fu_2854_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_22_fu_2954_p1() {
    zext_ln415_22_fu_2954_p1 = esl_zext<6,1>(tmp_80_fu_2946_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_23_fu_3046_p1() {
    zext_ln415_23_fu_3046_p1 = esl_zext<6,1>(tmp_83_fu_3038_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_24_fu_3138_p1() {
    zext_ln415_24_fu_3138_p1 = esl_zext<6,1>(tmp_86_fu_3130_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_25_fu_3230_p1() {
    zext_ln415_25_fu_3230_p1 = esl_zext<6,1>(tmp_89_fu_3222_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_26_fu_3322_p1() {
    zext_ln415_26_fu_3322_p1 = esl_zext<6,1>(tmp_92_fu_3314_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_27_fu_3414_p1() {
    zext_ln415_27_fu_3414_p1 = esl_zext<6,1>(tmp_95_fu_3406_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_28_fu_3506_p1() {
    zext_ln415_28_fu_3506_p1 = esl_zext<6,1>(tmp_98_fu_3498_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_29_fu_3598_p1() {
    zext_ln415_29_fu_3598_p1 = esl_zext<6,1>(tmp_101_fu_3590_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_2_fu_1114_p1() {
    zext_ln415_2_fu_1114_p1 = esl_zext<6,1>(tmp_20_fu_1106_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_30_fu_3690_p1() {
    zext_ln415_30_fu_3690_p1 = esl_zext<6,1>(tmp_104_fu_3682_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_31_fu_3782_p1() {
    zext_ln415_31_fu_3782_p1 = esl_zext<6,1>(tmp_107_fu_3774_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_32_fu_3874_p1() {
    zext_ln415_32_fu_3874_p1 = esl_zext<6,1>(tmp_110_fu_3866_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_33_fu_3966_p1() {
    zext_ln415_33_fu_3966_p1 = esl_zext<6,1>(tmp_113_fu_3958_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_34_fu_4058_p1() {
    zext_ln415_34_fu_4058_p1 = esl_zext<6,1>(tmp_116_fu_4050_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_35_fu_4150_p1() {
    zext_ln415_35_fu_4150_p1 = esl_zext<6,1>(tmp_119_fu_4142_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_36_fu_4242_p1() {
    zext_ln415_36_fu_4242_p1 = esl_zext<6,1>(tmp_122_fu_4234_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_37_fu_4334_p1() {
    zext_ln415_37_fu_4334_p1 = esl_zext<6,1>(tmp_125_fu_4326_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_38_fu_4426_p1() {
    zext_ln415_38_fu_4426_p1 = esl_zext<6,1>(tmp_128_fu_4418_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_39_fu_4518_p1() {
    zext_ln415_39_fu_4518_p1 = esl_zext<6,1>(tmp_131_fu_4510_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_3_fu_1206_p1() {
    zext_ln415_3_fu_1206_p1 = esl_zext<6,1>(tmp_23_fu_1198_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_40_fu_4610_p1() {
    zext_ln415_40_fu_4610_p1 = esl_zext<6,1>(tmp_134_fu_4602_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_41_fu_4702_p1() {
    zext_ln415_41_fu_4702_p1 = esl_zext<6,1>(tmp_137_fu_4694_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_42_fu_4794_p1() {
    zext_ln415_42_fu_4794_p1 = esl_zext<6,1>(tmp_140_fu_4786_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_43_fu_4886_p1() {
    zext_ln415_43_fu_4886_p1 = esl_zext<6,1>(tmp_143_fu_4878_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_44_fu_4978_p1() {
    zext_ln415_44_fu_4978_p1 = esl_zext<6,1>(tmp_146_fu_4970_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_45_fu_5070_p1() {
    zext_ln415_45_fu_5070_p1 = esl_zext<6,1>(tmp_149_fu_5062_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_46_fu_5162_p1() {
    zext_ln415_46_fu_5162_p1 = esl_zext<6,1>(tmp_152_fu_5154_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_47_fu_5254_p1() {
    zext_ln415_47_fu_5254_p1 = esl_zext<6,1>(tmp_155_fu_5246_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_48_fu_5346_p1() {
    zext_ln415_48_fu_5346_p1 = esl_zext<6,1>(tmp_158_fu_5338_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_49_fu_5438_p1() {
    zext_ln415_49_fu_5438_p1 = esl_zext<6,1>(tmp_161_fu_5430_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_4_fu_1298_p1() {
    zext_ln415_4_fu_1298_p1 = esl_zext<6,1>(tmp_26_fu_1290_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_50_fu_5530_p1() {
    zext_ln415_50_fu_5530_p1 = esl_zext<6,1>(tmp_164_fu_5522_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_51_fu_5622_p1() {
    zext_ln415_51_fu_5622_p1 = esl_zext<6,1>(tmp_167_fu_5614_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_52_fu_5714_p1() {
    zext_ln415_52_fu_5714_p1 = esl_zext<6,1>(tmp_170_fu_5706_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_53_fu_5806_p1() {
    zext_ln415_53_fu_5806_p1 = esl_zext<6,1>(tmp_173_fu_5798_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_54_fu_5898_p1() {
    zext_ln415_54_fu_5898_p1 = esl_zext<6,1>(tmp_176_fu_5890_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_55_fu_5990_p1() {
    zext_ln415_55_fu_5990_p1 = esl_zext<6,1>(tmp_179_fu_5982_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_56_fu_6082_p1() {
    zext_ln415_56_fu_6082_p1 = esl_zext<6,1>(tmp_182_fu_6074_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_57_fu_6174_p1() {
    zext_ln415_57_fu_6174_p1 = esl_zext<6,1>(tmp_185_fu_6166_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_58_fu_6266_p1() {
    zext_ln415_58_fu_6266_p1 = esl_zext<6,1>(tmp_188_fu_6258_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_59_fu_6358_p1() {
    zext_ln415_59_fu_6358_p1 = esl_zext<6,1>(tmp_191_fu_6350_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_5_fu_1390_p1() {
    zext_ln415_5_fu_1390_p1 = esl_zext<6,1>(tmp_29_fu_1382_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_60_fu_6450_p1() {
    zext_ln415_60_fu_6450_p1 = esl_zext<6,1>(tmp_194_fu_6442_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_61_fu_6542_p1() {
    zext_ln415_61_fu_6542_p1 = esl_zext<6,1>(tmp_197_fu_6534_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_62_fu_6634_p1() {
    zext_ln415_62_fu_6634_p1 = esl_zext<6,1>(tmp_200_fu_6626_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_63_fu_6726_p1() {
    zext_ln415_63_fu_6726_p1 = esl_zext<6,1>(tmp_203_fu_6718_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_6_fu_1482_p1() {
    zext_ln415_6_fu_1482_p1 = esl_zext<6,1>(tmp_32_fu_1474_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_7_fu_1574_p1() {
    zext_ln415_7_fu_1574_p1 = esl_zext<6,1>(tmp_35_fu_1566_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_8_fu_1666_p1() {
    zext_ln415_8_fu_1666_p1 = esl_zext<6,1>(tmp_38_fu_1658_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_9_fu_1758_p1() {
    zext_ln415_9_fu_1758_p1 = esl_zext<6,1>(tmp_41_fu_1750_p3.read());
}

void relu_array_array_ap_ufixed_64u_relu_config4_s::thread_zext_ln415_fu_930_p1() {
    zext_ln415_fu_930_p1 = esl_zext<6,1>(tmp_14_fu_922_p3.read());
}

}

