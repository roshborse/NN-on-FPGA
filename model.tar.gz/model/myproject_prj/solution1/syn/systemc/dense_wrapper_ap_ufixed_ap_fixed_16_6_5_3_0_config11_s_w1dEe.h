// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_H__
#define __dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 476;
  static const unsigned AddressRange = 2;
  static const unsigned AddressWidth = 1;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_ram) {
        ram[0] = "0b10100010111111100000000000000001000101111000000000111110000101000110100000000000000011000000000010000100000001000011000000100000100000011111111111011101011010100000000000000000111101001000100000000000011111000011000000000000000110000001000000110000101100000001000010000000100000001001000000000000111100111111000000000001000010110001011111000000111111000011000000000000000010100000111111100101111111000001000000000001000000110111100000000001100000000000000001000000000000100000";
        ram[1] = "0b00000000011111100000111011000000011111000000100000000000000000000110000000000000011111100000100000000000000110111011111011000000110110111010000001111011000000100000000000000000000000101001000010000000000000000000111110000000111000100001000010100000000000011001000000000000111110011101100000000000100000000010000000000000110001000001000000000100000000000000000000000000000000100011000100000000111001000100011111000000111000011111000001000011000000110111000000000000111100000101";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe) {


static const unsigned DataWidth = 476;
static const unsigned AddressRange = 2;
static const unsigned AddressWidth = 1;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_ram* meminst;


SC_CTOR(dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe) {
meminst = new dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_ram("dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~dense_wrapper_ap_ufixed_ap_fixed_16_6_5_3_0_config11_s_w1dEe() {
    delete meminst;
}


};//endmodule
#endif
