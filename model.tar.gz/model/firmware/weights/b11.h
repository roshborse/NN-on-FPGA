//Numpy array shape [5]
//Min -0.187500000000
//Max 0.250000000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {-0.18750, -0.15625, 0.00000, 0.15625, 0.25000};
#endif

#endif
